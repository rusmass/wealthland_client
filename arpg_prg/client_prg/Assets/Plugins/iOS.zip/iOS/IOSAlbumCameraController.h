//
//  IOSAlbumCameraController.h
//  Unity-iPhone
//
//  Created by AnYuanLzh
//
//

@interface IOSAlbumCameraController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@end
