﻿using System;

namespace Client.UI
{
	public partial class UITipWaitingWindow
	{
		class Layout
		{
			public static string lb_txt="tipTxt";
			public static string btn_cancle="tipcancle";
			public static string lb_lefetime="leftTime";
		}
	}
}

