﻿using Client;
using System;
using UnityEngine;
using UnityEngine.UI;

namespace Client.UI
{
	public class UIOptimizeTestWindow : UIWindow<UIOptimizeTestWindow, UIOptimizeTestController>
	{
		protected override void _Init (GameObject go)
		{
			
		}

        protected override void _OnShow()
        {
			
        }

        protected override void _OnHide ()
		{
			
		}

		protected override void _Dispose ()
		{
			
		}
	}
}

