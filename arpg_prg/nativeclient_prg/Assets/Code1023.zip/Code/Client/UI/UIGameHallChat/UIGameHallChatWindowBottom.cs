﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Client.UI
{
	public partial class UIGameHallChatWindow
	{
		private void _InitBottom(GameObject go)
		{
			
		}

		private void _OnShowBottom()
		{
			
		}

		private void _OnHideBottom()
		{
			
		}

		private void _OnDisposeBottom()
		{
			
		}
	}
}

