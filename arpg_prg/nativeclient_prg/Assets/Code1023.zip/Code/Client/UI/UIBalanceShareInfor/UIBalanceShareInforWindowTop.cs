﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Client.UI
{
	public partial class UIBalanceShareInforWindow
	{

		private void _InitTop(GameObject go)
		{
//			_titleTxt = go.GetComponentEx<Text> (Layout.lb_title);
		}

		private void _OnShowTop()
		{
//			_titleTxt.text = "";
		}

		// set the txt context
		public void setTitle (string str)
		{
//			_titleTxt.text = str;
		}


//		private Text _titleTxt;

	}
}

