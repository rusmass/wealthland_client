﻿using System;

namespace Client
{
	public enum GameEvents
	{
		None,
        BattleInfo,
        RoleTurnChanged,
        CheckDay,
	}
}

