﻿
namespace Client
{
    /// <summary>
    /// 定义人物的类型的
    /// </summary>
    public enum ObjectType
    {
        Invalid = -1,
        Npc,
        Player,
        Ghost,
    }
}
