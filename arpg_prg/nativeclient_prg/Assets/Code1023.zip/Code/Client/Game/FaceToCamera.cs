﻿using UnityEngine;
using System.Collections;

/// <summary>
///  未使用具体功能
/// </summary>
public class FaceToCamera : MonoBehaviour {


	// Use this for initialization
	void Start () {
	
	}

	// Update is called once per frame
	void Update () 
	{
//		gameObject.transform.LookAt(Camera.main.transform.position);
//		Vector3 rotation = gameObject.transform.localEulerAngles;
//		rotation.x = 0; 
//		rotation.y = gameObject.transform.localEulerAngles.y;
//		rotation.z = gameObject.transform.localEulerAngles.z;
//		gameObject.transform.localEulerAngles = rotation;

//		gameObject.transform.rotation = Quaternion.Slerp(gameObject.transform.rotation, Quaternion.LookRotation(Camera.main.transform.position - gameObject.transform.position), 10 * Time.deltaTime);
	}
}
