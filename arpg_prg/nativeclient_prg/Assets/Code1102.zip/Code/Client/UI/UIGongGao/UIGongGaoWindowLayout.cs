﻿using System;

namespace Client.UI
{
	public partial class UIGongGaoWindow
	{
		class Layout
		{
			public static string btn_title="btn_gonggao1";

			public static string img_gonggao="img_gonggao";

			public static string txt_title="txt_title";

			public static string txt_content="txt_content";

			public static string btn_close="surebtn";
		}
	}
}

