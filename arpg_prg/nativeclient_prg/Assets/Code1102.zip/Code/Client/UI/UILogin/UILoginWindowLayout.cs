﻿using System;

namespace Client.UI
{
	public partial class UILoginWindow
	{
		class Layout
		{
			public static string lb_loginusename="usernametxt";
			public static string lb_loginpassword="userpasswordtxt";
			public static string toggle_rember="toggleremember";
			public static string btn_forget="btnforget";

			public static string btn_longing="loginbtn";
			public static string btn_wechatLogin="weichatlogin";
			public static string btn_regist="registbtn";

			public static string btn_login="loginbtnnew";
			public static string img_tipword="tipword";

			public static string btn_server="btn_server";
			public static string btn_modifypassword="btn_modifypassword";
			public static string btn_fankui="btn_fankui";


			public static string btn_PhoneLogin="phonelogin";

			public static string img_loginbg="loginboardimg";
			public static string btn_closePhoneBoard="btn_closeboard";

			public static string img_bottom="bottom";

			public static string lb_version = "version";

		}
	}
}

