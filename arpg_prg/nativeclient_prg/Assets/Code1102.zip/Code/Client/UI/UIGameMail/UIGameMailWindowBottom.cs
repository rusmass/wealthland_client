﻿using System;

namespace Client.UI
{
	public partial class UIGameMailWindow
	{
	}
}

