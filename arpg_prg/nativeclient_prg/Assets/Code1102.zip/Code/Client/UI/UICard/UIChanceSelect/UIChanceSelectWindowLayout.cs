﻿using System;

namespace Client.UI
{
	public partial class UIChanceSelectWindow
	{
		class Layout
		{
			public static string btn_opportunity="btn_opportunity";

			public static string btn_chance="btn_chance";

			public static string lb_clock="lb_time";
		}
	}
}

