﻿using System;

namespace Client.UI
{
	public partial class UIStartGuildWindow
    {
		class Layout
		{
            public static string sr_ScrollView = "Scroll View";
            public static string trans_Parent = "Scroll View/Viewport/Content";
            public static string rimg_Show = "rimg_Show";

            public static string btn_Jump = "btn_Jump";
            
            public static string tg_Parent = "tg_Parent";
            public static string toggle_1 = "toggle_1";
            
        }
	}
}

