﻿using System;

namespace GameNet
{
    /// <summary>
    ///未引用 ， 后台返回游戏版本的数据单元
    /// </summary>
	public class CheckVersion
	{
		public string versionCode;
	}
}

