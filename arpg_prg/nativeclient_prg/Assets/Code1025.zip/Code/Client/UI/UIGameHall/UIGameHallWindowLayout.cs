﻿using System;

namespace  Client.UI
{
	public partial class UIGameHallWindow
	{
		class Layout
		{
			// top
			public static string img_head="img_head";

			public static string btn_head="btn_head";

			public static string txt_name="txt_name";

			public static string txt_id="txt_id";

			public static string btn_mail="btn_mail";

			public static string btn_gonggao="btn_gonggao";

			public static string btn_share="btn_share";

			public static string img_herosex="img_herosex";



			//center
			public static string btn_danji="btn_danji";

			public static string btn_net="btn_net";

			public static string btn_room="btn_room";

			public static string btn_enteroom="btn_enterroom";

			//bottom
			public static string btn_paihang="btn_paihang";

			public static string btn_haoyou="btn_haoyou";

			public static string btn_help="btn_help";

			public static string btn_set="btn_set";

			//enterroom
			public static string img_enteroom="img_enteroom";

			public static string lb_numtxt="nmutxt";

			public static string btn_num="btn_num";

			public static string btn_numsure="btn_numsure";

			public static string btn_closeenteroom="btn_closeenteroom";

			/// <summary>
			/// The button reput. 重新输入密码
			/// </summary>
			public static string btn_reput="btn_reput";

			/// <summary>
			/// The button delete.回退键
			/// </summary>
			public static string btn_delete="btn_delete";

			/// <summary>
			/// The button chat.聊天按钮
			/// </summary>
			public static string btn_chat="btnchat";

			/// <summary>
			/// The lb chat.显示聊天的话术
			/// </summary>
			public static string lb_chat="textshow";

		}
	}
}

