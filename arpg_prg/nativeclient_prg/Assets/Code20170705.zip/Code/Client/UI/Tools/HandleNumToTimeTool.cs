﻿using System;

namespace Client.UI
{
	public class HandleNumToTimeTool
	{
		public static string  ChangeNumberToTime(float value)
		{
			int timer = (int)((value % 3600));
			string timerStr;
			if (timer < 10)
			{
				timerStr = "0" + timer.ToString();
			}
			else
			{
				timerStr = timer.ToString();
			}
			return timerStr;
		}
	}
}

