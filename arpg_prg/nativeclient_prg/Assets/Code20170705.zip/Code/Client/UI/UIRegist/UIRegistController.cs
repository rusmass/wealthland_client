﻿using System;

namespace Client.UI
{
	public class UIRegistController:UIController<UIRegistWindow,UIRegistController>
	{
		public static readonly string TYPE_REGIST="regist";

		public static readonly string TYPE_MODIFY="modify";

		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/uiregistgo.ab";
			}
		}

		public UIRegistController ()
		{
		}

		protected override void _Dispose ()
		{

		}

		protected override void _OnLoad ()
		{

		}

		protected override void _OnShow ()
		{

		}

		protected override void _OnHide ()
		{

		}

		/// <summary>
		/// The type of the window.窗口的类型
		/// </summary>
		public string windowType;
	}
}

