﻿using System;

namespace Client.UI
{
	public class UIGameBindPhoneWindowController:UIController<UIGameBindPhoneWindow,UIGameBindPhoneWindowController>
	{

		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/uibindphone.ab";
			}
		}

		protected override void _Dispose ()
		{

		}

		protected override void _OnLoad ()
		{

		}

		protected override void _OnShow ()
		{

		}

		protected override void _OnHide ()
		{

		}

		public void CheckPhoneState(int value)
		{
			if (null != _window && getVisible ())
			{
				(_window as UIGameBindPhoneWindow).CheckPhoneState (value);
			}
		}


		public UIGameBindPhoneWindowController ()
		{
		}
	}
}

