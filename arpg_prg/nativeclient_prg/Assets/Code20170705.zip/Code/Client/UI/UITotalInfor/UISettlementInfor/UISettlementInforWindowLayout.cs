﻿using System;

namespace Client.UI
{
	public partial class UISettlementInforWindow
	{
		class Layout
		{
			public static string lb_income="lb_income";
			public static string lb_payment="lb_pay";
			public static string lb_settlement="lb_settlement";

			public static string img_income="imgIncome";
			public static string img_payment="imgExpenditure";
			public static string img_checkout="imgSettlement";

			public static string img_add="imgAdd";

			public static string btn_record="btn_record";
		}
	}
}

