﻿
using System;

namespace Client.GameFSM
{
	public class LoginState:FSMState
	{
		public LoginState (Game content)
			:base(content,FSMStateType.LoginState)
		{
			
		}

		public override void Enter (Core.FSM.Event e, Core.FSM.FiniteStateMachine<Game>.State lastState)
		{
//			var control = Client.UIControllerManager.Instance.GetController<Client.UI.UILoginController>();
//			control.setVisible(true);

			var control = Client.UIControllerManager.Instance.GetController<Client.UI.UIStartGuildWindowController> ();
			control.setVisible (true);
		}

		protected override void _OnExit (Core.FSM.Event e, Core.FSM.FiniteStateMachine<Game>.State nextState)
		{
			
		}

		protected override Core.FSM.FiniteStateMachine<Game>.State _DoEvent (Core.FSM.Event e)
		{
			switch((FSMEventType)e.ID)
			{
			//case FSMEventType.SelectRoleEvent:
				//return new SelectRoleState(_Content);

			case FSMEventType.GameHallEvent:
				return new GameHallState(_Content);

			default:
				break;
			}
			return this;
		}

		protected override Core.FSM.FiniteStateMachine<Game>.State _DoTick (float deltaTime)
		{
			return this;
		}
	}
}

