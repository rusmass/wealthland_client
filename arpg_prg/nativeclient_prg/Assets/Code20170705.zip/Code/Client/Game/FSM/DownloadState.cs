﻿using Core;
using Core.Web;
using System;
using Core.FSM;
using System.Collections;
using System.Collections.Generic;

namespace Client.GameFSM
{
	public class DownloadState : FSMState
	{
		public DownloadState (Game content)
			:base(content, FSMStateType.DownloadState)
		{
		}

		protected override FSM.State _DoTick (float deltaTime)
		{
			if (WebManager.IsInited ()) 
			{
                if (!_loaded)
                {
                    Metadata.MetadataManager.Instance.LoadMetadata();
                    _loaded = true;
                }
                else
                {
				    //return 	new LoadingState (_Content);	
					return new LoginState(_Content);
//					return new SelectRoleState(_Content);
                }
			}

			return this;
		}

        private bool _loaded;
	}
}

