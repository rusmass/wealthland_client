﻿using System;
using Core.FSM;

namespace Client.UnitFSM
{
    public enum FSMEventType
    {
        None,
        StayEvent,
        RollEvent,
        WalkEvent,
        SelectEvent,
        UpGradeEvent,
        SuccessEvent,
    }

    public class FSMEvent : Event
    {
        public FSMEvent(FSMEventType type)
            : base((int)type)
        {

        }
    }

    public class StayEvent : FSMEvent
    {
        public StayEvent()
            : base(FSMEventType.StayEvent)
        {

        }
    }

    public class RollEvent : FSMEvent
    {
        public RollEvent(int points)
            : base(FSMEventType.RollEvent)
        {
            this.points = points;
        }

        public int points;
    }



    public class WalkEvent : FSMEvent
    {
        public WalkEvent(Func<float, bool> lpfnWalk)
            : base(FSMEventType.WalkEvent)
        {
            this.lpfnWalk = lpfnWalk;
        }

        public Func<float, bool> lpfnWalk;
    }

    public class SelectEvent : FSMEvent
    {
        public SelectEvent(int pos, int id)
            : base(FSMEventType.SelectEvent)
        {
            this.pos = pos;
            this.cardID = id;
        }

        public int pos; //当前角色所在地图块的index
        public int cardID; // 所选择卡片的ID
    }

    public class UpGradeEvent : FSMEvent
    {
        public UpGradeEvent(Action func)
            : base(FSMEventType.UpGradeEvent)
        {
            lpfnUpGradeToInner = func;
        }

        public Action lpfnUpGradeToInner;
    }

    public class SuccessEvent : FSMEvent
    {
        public SuccessEvent()
            : base(FSMEventType.SuccessEvent)
        {

        }
    } 
}

