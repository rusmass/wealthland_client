using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class IntDTO
{
	public int value;
	public IntDTO ()
	{
	}
	public IntDTO(int v){
		this.value = v;
	}
}


