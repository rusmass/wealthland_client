﻿using System;

namespace Metadata
{
    [Export(ExportFlags.ExportRaw)]
    public partial class ModelTemplate : Template
    {
        public string modelName;
        public string modelPath;
    }
}
