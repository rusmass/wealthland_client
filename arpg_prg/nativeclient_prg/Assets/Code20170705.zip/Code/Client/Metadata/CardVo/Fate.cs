﻿using System;

namespace Metadata
{
	public partial class Fate
	{
		//card name
		public string title;

		//card image path
		public string cardPath;

		public string cardIntroduce;

		public int id;
	}
}

