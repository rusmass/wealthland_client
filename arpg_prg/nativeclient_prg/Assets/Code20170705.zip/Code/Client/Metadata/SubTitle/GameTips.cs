﻿using System;

namespace Metadata
{
	[ExportAttribute(ExportFlags.ExportRaw)]
	public partial class GameTips:Config
	{
		public string newTip1;
		public string newTip2;
		public string newTip3;
		public string newTip4;
		public string newTip5;
		public string newTip6;

		public string oldTip1;
		public string oldTip2;
		public string oldTip3;
		public string oldTip4;
		public string oldTip5;
		public string oldTip6;
		public string oldTip7;
		public string oldTip8;

		public string oldMoreTip1;
		public string oldMoreTip2;
		public string oldMoreTip3;
		public string oldMoreTip4;
		public string oldMoreTip5;
		public string oldMoreTip6;

		/// <summary>
		/// The enter tip. 进入内圈的总结s
		/// </summary>
		public string enterTip;

		public string innerTip1;
		public string innerTip2;
		public string innerTip3;
		public string innerTip4;
		public string innerTip5;
		public string innerTip6;
		public string innerTip7;
		public string innerTip8;
		public string innerTip9;
		public string innerTip10;
		public string innerTip11;
		public string innerTip12;
		public string innerTip13;
		public string innerTip14;
		public string innerTip15;

		public string enterResult1;
		public string enterResult2;
		public string enterResult3;
	}
}

