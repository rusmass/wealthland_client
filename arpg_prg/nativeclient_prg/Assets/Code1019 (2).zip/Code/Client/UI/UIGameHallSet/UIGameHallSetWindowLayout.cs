﻿
using System;

namespace Client.UI
{
	public partial class UIGameHallSetWindow
	{
		class Layout
		{
			public static string img_sound="soundimg";

			public static string img_music="musicimg";

			public static string btn_back="backbtn";
			public static string btn_logout="logoutbtn";

			public static string btn_sound="soundbtn";
			public static string btn_music="musicbtn";

		}
	}
}

