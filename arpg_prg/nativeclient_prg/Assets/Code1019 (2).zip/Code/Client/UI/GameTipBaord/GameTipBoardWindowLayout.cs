﻿using System;

namespace Client.UI
{
	public partial class GameTipBoardWindow
	{
        /// <summary>
        /// 布局用到的ui
        /// </summary>
		class Layout
		{
			public static string lb_txt="tipTxt";
			public static string btn_tip="tipbtn";
			public static string btn_know="knowbtn";

			public static string img_bgimg="bgimg";
		}
	}
}

