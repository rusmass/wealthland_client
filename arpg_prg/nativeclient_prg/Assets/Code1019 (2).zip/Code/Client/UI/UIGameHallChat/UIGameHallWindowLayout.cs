﻿using System;

namespace Client.UI
{
	public partial class UIGameHallChatWindow
	{
		private class Layout
		{
			public static string btn_back="btn_back";

			public static string lb_input="inputtxt";

			public static string btn_send="btn_sendword";

			public static string chatitem="chatitem";

			public static string scrollrect="debtscroll";

		}
	}
}

