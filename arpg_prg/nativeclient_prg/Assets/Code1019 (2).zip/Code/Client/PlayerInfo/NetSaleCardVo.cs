﻿using System;

/// <summary>
/// Net sale card vo. 网络版卖出卡牌的vo
/// </summary>
public class NetSaleCardVo
{
    public NetSaleCardVo()
    {
    }

    public int cardId;
    public int cardType;
    public int cardNumber;
}
