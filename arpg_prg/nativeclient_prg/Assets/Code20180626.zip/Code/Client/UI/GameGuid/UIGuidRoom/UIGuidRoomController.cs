﻿using System;

namespace Client.UI
{
	public class UIGuidRoomController : UIController<UIGuidRoomWindow, UIGuidRoomController>
	{
		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/newplayerguid/uinewguidroom.ab";
			}
		}

		public UIGuidRoomController()
		{
		}
	}
}

