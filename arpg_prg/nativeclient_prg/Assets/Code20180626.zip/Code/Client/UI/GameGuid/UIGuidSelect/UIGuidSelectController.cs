﻿using System;

namespace Client.UI
{
	public class UIGuidSelectController : UIController<UIGuidSelectWindow, UIGuidSelectController>
	{
		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/newplayerguid/uinewguidselect.ab";
			}
		}

		public UIGuidSelectController()
		{

		}
	}
}

