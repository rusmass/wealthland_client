﻿using System;
using UnityEngine;

namespace Client.UI
{
	public class UIGuidPaybackWindow : UIWindow<UIGuidPaybackWindow, UIGuidPaybackController>
	{
		public UIGuidPaybackWindow()
		{
		}

		protected override void _Init (GameObject go)
		{
			
		}

		protected override void _OnShow ()
		{
			
		}

		protected override void _OnHide ()
		{
			
		}

		protected override void _Dispose ()
		{
			
		}
	}
}

