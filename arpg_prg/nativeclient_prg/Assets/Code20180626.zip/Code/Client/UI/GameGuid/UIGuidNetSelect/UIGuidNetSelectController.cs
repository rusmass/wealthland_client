﻿using System;

namespace Client.UI
{
	public class UIGuidNetSelectController : UIController<UIGuidNetSelectWindow, UIGuidNetSelectController>
	{
		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/newplayerguid/uinewguidnetselect.ab";
			}
		}

		public UIGuidNetSelectController()
		{
		}
	}
}

