﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client.UI
{
  partial class UINativeWebWindow
  {
        class Layout
        {
            /// <summary>
            /// 关闭按钮
            /// </summary>
            public static string closeBtn = "closebtn";
            /// <summary>
            /// 背景图片
            /// </summary>
            public static string blackbg = "blackbg";
        }
  }
}
