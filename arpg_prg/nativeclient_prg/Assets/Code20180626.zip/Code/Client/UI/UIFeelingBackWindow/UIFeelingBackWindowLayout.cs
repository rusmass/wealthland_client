﻿
using System;

namespace Client.UI
{
	public partial class UIFeelingBackWindow
	{
		class Layout
		{
			public static string btn_sure="surebtn";
			public static string btn_close="closebtn";
			public static string text_input= "text_feeling";
		}
	}
}

