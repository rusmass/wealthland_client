﻿using UnityEngine;
using System.Collections;

namespace Client.UI
{
    public partial class UIPersonalGameRecodeWindow
    {
        class Layout
        {
            public static string sc = "SC";
            public static string grid = "Panel";
            public static string item = "Item";
            public static string back = "Back";
        }
    }
}
