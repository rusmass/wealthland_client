﻿
using System;

namespace Client.UI
{
	public partial class UIGameAutoTipWindow
    {
		class Layout
		{
            /// <summary>
            ///提示内容文本框
            /// </summary>
			public static string lb_txt="tipTxt";

            /// <summary>
            /// 文本框标题栏
            /// </summary>
            public static string lb_title = "titleTxt";

			public static string img_bgimg="bgimg";
		}
	}
}

