using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/// <summary>
/// socket 的数据类型,接收socket，根据不同接口号，进行对应操作
/// </summary>

public class SocketModel
{
	public int type{get;set;}
	public string message{get;set;}
}

