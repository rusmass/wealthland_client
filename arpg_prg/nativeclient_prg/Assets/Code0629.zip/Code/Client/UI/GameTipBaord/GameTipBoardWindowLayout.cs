﻿using System;

namespace Client.UI
{
	public partial class GameTipBoardWindow
	{
		class Layout
		{
			public static string lb_txt="tipTxt";
			public static string btn_tip="tipbtn";
			public static string btn_know="knowbtn";

			public static string img_bgimg="bgimg";
		}
	}
}

