﻿using System;

namespace GameNet
{
	public class FankuiVo
	{
		/// <summary>
		/// The .：”反馈建议”//用户输入的文本
		/// </summary>
		public string input;
	}

	public class FankuiBackVo
	{
		////0成功，1失败 
		public int status;
		/// <summary>
		/// The .：”反馈提示玩家”
		/// </summary>
		public string msg;


	}


}

