using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// socket 的数据类型
public class SocketModel
{
	public int type{get;set;}
	public string message{get;set;}
}

