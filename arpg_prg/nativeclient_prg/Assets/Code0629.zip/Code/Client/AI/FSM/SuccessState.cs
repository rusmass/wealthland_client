﻿using System;
using Client.Unit;
using Client.UI;

namespace Client.UnitFSM
{
    public class SuccessState : FSMState
    {
        public SuccessState(Room content)
            : base(content, FSMStateType.SuccessState)
        {
        }

        public override void Enter(Core.FSM.Event e, Core.FSM.FiniteStateMachine<Room>.State lastState)
        {
            CardManager.Instance.OpenCard((int)SpecialCardType.SuccessType);
        }

        protected override void _OnExit(Core.FSM.Event e, Core.FSM.FiniteStateMachine<Room>.State nextState)
        {

        }

        protected override Core.FSM.FiniteStateMachine<Room>.State _DoTick(float deltaTime)
        {
            return this;
        }
    }
}

