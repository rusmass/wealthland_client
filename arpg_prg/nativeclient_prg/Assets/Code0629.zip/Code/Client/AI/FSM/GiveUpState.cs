﻿using System;
using Core.FSM;

namespace Client.UnitFSM
{
	public class GiveUpState : FSMState
	{
		public GiveUpState(Room content)
			: base(content, FSMStateType.GiveUpState)
		{

		}

		public override void Enter(Event e, FSM.State lastState)
		{
			
		}

		protected override void _OnExit(Event e, FSM.State nextState)
		{

		}

		protected override FiniteStateMachine<Room>.State _DoEvent (Event e)
		{
			switch ((FSMEventType)e.ID) 
			{
			case FSMEventType.StayEvent:
				return new StayState (_Content);
			case FSMEventType.WalkEvent:
				return new WalkState (_Content);

			default :
				break;
			}

			return this;
		}

		protected override FiniteStateMachine<Room>.State _DoTick(float deltaTime)
		{
			return new StayState(_Content) ;
		}
	}
}

