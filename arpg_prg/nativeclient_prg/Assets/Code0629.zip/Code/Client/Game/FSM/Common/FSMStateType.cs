﻿using System;

namespace Client.GameFSM
{
	public enum FSMStateType
	{
		None,
		StartState,
		UnpackState,
		DownloadState,
		LoginState,
		SelecRoleState,
		LoadingState,
		GameHallState,
		NetSelectRoleEvent,
	}
}

