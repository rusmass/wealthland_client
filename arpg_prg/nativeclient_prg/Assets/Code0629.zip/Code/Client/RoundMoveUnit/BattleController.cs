﻿using System;
using Client.Scenes;
using UnityEngine;

namespace Client.Unit
{
	public class BattleController
	{
		private BattleController ()
		{
		}

		public void Send_StartGame()
		{			
			VirtualServer.Instance.Handle_StartGame (133);
		}

		public void InitBattle()
		{
			
		}

		public void Tick(float deltaTime)
		{
			if (null != _room) 
			{
				_room.Tick (deltaTime);
			}
		}

		public void Send_RequestRoll()
		{
			Console.WriteLine ("Send_RequestRoll index = {0}", _room.CurrentPlayerIndex);
			VirtualServer.Instance.Handle_RequestRoll (_room.CurrentPlayerIndex, _room.RoomID);
		}

		public void Send_RoleSelected(int sel = 1)
		{
			if (GameModel.GetInstance.isPlayNet == false)
			{
				NetGameSeletcResult (sel);
			}
			else
			{
				
			}
		}

		public void NetGameSeletcResult(int sel = 1)
		{
			VirtualServer.Instance.Handle_RequestSelect (_room.CurrentPlayerIndex, _room.RoomID, sel);
		}

		public void Handle_NewStayState(int ownerIndex)
		{
			if (null != _room) 
			{
				_room.Re_StayState (ownerIndex);
			}
		}

		public void Handle_NewRollState(int points,int[] arr=null)
		{
			if (null != _room) 
			{
				_room.Re_RollState (points,arr);
			}
		}

		public void Handle_NewWalkState()
		{
			if (null != _room) 
			{
				_room.Re_WalkState ();
			}
		}

		public void Handle_NewSelectState(int id)
		{
			if (null != _room) 
			{
				_room.Re_SelectState (id);
			}
		}

		/// <summary>
		/// Handles the new state of the up grade. 单机版游戏进入到内圈
		/// </summary>
        public void Handle_NewUpGradeState()
        {			
//			if (GameModel.GetInstance.isPlayNet == false)
//			{
				NetHandlerUpGradeState ();
//			}
        }

		/// <summary>
		/// Nets the state of the handler up grade.  网络版调用升级的接口
		/// </summary>
		private void NetHandlerUpGradeState()
		{
			if (null != _room)
			{
				_room.Re_UpGradeState();
			}
		}



        public void Handle_NewSuccessState()
        {
            if (null != _room)
            {
                _room.Re_SuccessState();
            }
        }

        public void Send_WalkFinish()
        {
            VirtualServer.Instance.Handle_WalkFinish(_room.RoomID);
        }

		/// <summary>
		/// Sends up grade finish. 单机玩法发送进入内圈成功
		/// </summary>
		/// <param name="select">If set to <c>true</c> select.</param>
        public void Send_UpGradeFinish(bool select)
        {
			if (GameModel.GetInstance.isPlayNet == false)
			{
				NetGameEnterInnerFinished (select);
			}
			else
			{

			}
        }


		public void NetGameEnterInnerFinished(bool iselect=true)
		{
			VirtualServer.Instance.Handle_UpGradeFinished(_room.RoomID, iselect);
		}

        public int CurrentPlayerIndex
        {
            get { return _room.CurrentPlayerIndex; }
        }

        public int CurrentTurnCount
        {
            get
			{
//				if (PlayerManager.Instance.IsHostPlayerTurn () == true)
//				{
//					if (null != PlayerManager.Instance.HostPlayerInfo)
//					{
//						if(PlayerManager.Instance.HostPlayerInfo.Age !=_room.CurrentTurnCount)
//						{
//							PlayerManager.Instance.HostPlayerInfo.Age = _room.CurrentTurnCount;
//						}
//					}
//				}
				return _room.CurrentTurnCount;
			}
        }

		private Room _room = Room.Instance;

		private static BattleController _instance;

		public static BattleController Instance
		{
			get
			{
				if (null == _instance)
				{
					_instance= new BattleController();
				}
				return _instance;
			}
		}

		public void Dispose()
		{
//			if (null == _instance)
//			{
//				return;
//			}
			_room.Dispose ();
//			_instance = null;
		}

		public void ReStartGame()
		{
			if (null != _room)
			{
				_room.ReStartGame ();
			}
		}
	}
}

