﻿using System;

public class GonggaoVo
{
	public GonggaoVo ()
	{
	}

	public string title;
	public string content;

	/// <summary>
	/// The type. 公告的类型，0是文字  ， 1是图片
	/// </summary>
	public int type=0;

}

