﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace Client.UI
{
    public partial class UISelfChooseWindow
    {

        private void _OnInitDebt(GameObject go)
        {
            this.input_payTax = go.GetComponentEx<InputField>(Layout.input_payTax);
            this.input_payHouse = go.GetComponentEx<InputField>(Layout.input_payhouse);
            this.input_payEduc = go.GetComponentEx<InputField>(Layout.input_payeduc);
            this.input_payCar = go.GetComponentEx<InputField>(Layout.input_paycar);
            this.input_payCard = go.GetComponentEx<InputField>(Layout.input_paycard);
            this.input_payNess = go.GetComponentEx<InputField>(Layout.input_payness);

            this.input_payChild = go.GetComponentEx<InputField>(Layout.input_paychild);

            this.input_DebtHouse = go.GetComponentEx<InputField>(Layout.input_debthouse);
            this.input_DebtEduc = go.GetComponentEx<InputField>(Layout.input_debteduc);
            this.input_DebtCar = go.GetComponentEx<InputField>(Layout.input_debtcar);
            this.input_DebtCard = go.GetComponentEx<InputField>(Layout.input_debtcard);

            this.btn_closeDebt = go.GetComponentEx<Button>(Layout.btn_closepay);
            this.txt_debt_totaldebt = go.GetComponentEx<Text>(Layout.txt_pay_totalpay);

        }

        private void _OnShowDebt()
        {
            EventTriggerListener.Get(this.btn_closeDebt.gameObject).onClick += _OnCloseDebt;
            input_payTax.onEndEdit.AddListener(_OnModifyPayTax);
            input_payHouse.onEndEdit.AddListener(_OnModifyPayHouse);
            input_payEduc.onEndEdit.AddListener(_OnModifyPayEduc);
            input_payCar.onEndEdit.AddListener(_OnModifyPayCar);
            input_payCard.onEndEdit.AddListener(_OnModifyPayCard);
            input_payNess.onEndEdit.AddListener(_OnModifyPayNess);
            input_payChild.onEndEdit.AddListener(_OnModifyPayChild);

            input_DebtHouse.onEndEdit.AddListener(_OnModifyDebtHouse);
            input_DebtEduc.onEndEdit.AddListener(_OnModifyDebtEduc);
            input_DebtCar.onEndEdit.AddListener(_OnModifyDebtCar);
            input_DebtCard.onEndEdit.AddListener(_OnModifyDebtCard);

            _UpdateTotalPay();
        }

        private void _OnHideDebt()
        {
            EventTriggerListener.Get(this.btn_closeDebt.gameObject).onClick -= _OnCloseDebt;
            input_payTax.onEndEdit.RemoveListener(_OnModifyPayTax);
            input_payHouse.onEndEdit.RemoveListener(_OnModifyPayHouse);
            input_payEduc.onEndEdit.RemoveListener(_OnModifyPayEduc);
            input_payCar.onEndEdit.RemoveListener(_OnModifyPayCar);
            input_payCard.onEndEdit.RemoveListener(_OnModifyPayCard);
            input_payNess.onEndEdit.RemoveListener(_OnModifyPayNess);
            input_payChild.onEndEdit.RemoveListener(_OnModifyPayChild);

            input_DebtHouse.onEndEdit.RemoveListener(_OnModifyDebtHouse);
            input_DebtEduc.onEndEdit.RemoveListener(_OnModifyDebtEduc);
            input_DebtCar.onEndEdit.RemoveListener(_OnModifyDebtCar);
            input_DebtCard.onEndEdit.RemoveListener(_OnModifyDebtCard);
        }

        private void _UpdateTotalPay()
        {
            this.newInfor.UptatePaymentData();
            this.txt_debt_totaldebt.text = this.newInfor.MonthFixedPay.ToString();
        }
             

        private void _OnCloseDebt(GameObject go)
        {
            this.img_debt.SetActiveEx(false);
            this.newInfor.UptatePaymentData();
            this._UpdateIncomeAndPay();
        }

        private void _InitPlayerDebtData()
        {
            input_payTax.text= this.newInfor.initTax.ToString();
            input_payHouse.text = this.newInfor.initHouseMortgages.ToString();
            input_payEduc.text = this.newInfor.initEducationLoan.ToString();
            input_payCar.text = this.newInfor.initCarLoan.ToString();
            input_payCard.text = this.newInfor.initCardLoan.ToString();
            input_payNess.text = this.newInfor.initOtherSpend.ToString();
            input_payChild.text = this.newInfor.oneChildPrise.ToString();

            input_DebtHouse.text = this.newInfor.fixedHouseMortgages.ToString();
            input_DebtEduc.text = this.newInfor.fixedEducation.ToString();
            input_DebtCar.text = this.newInfor.fixedCarLoan.ToString();
            input_DebtCard.text = this.newInfor.fixedCardLoan.ToString();
        }

        /// <summary>
        /// 修改税金
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyPayTax(string value)
        {
            var tmpTax = 0;
            if(""!=value)
            {
                tmpTax = int.Parse(value);
            }
            this.newInfor.initTax = tmpTax;
            _UpdateTotalPay();
            //_SetPayTax(tmpTax);
        }

        /// <summary>
        /// 设置税金
        /// </summary>
        /// <param name="value"></param>
        private void _SetPayTax(int value)
        {
            input_payTax.text = value.ToString();
        }

        /// <summary>
        /// 修改住房支出
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyPayHouse(string value)
        {
            var tmpPayHouse = 0;
            if(""!= value)
            {
                tmpPayHouse = int.Parse(value);
            }

            this.newInfor.initHouseMortgages = tmpPayHouse;
            _SetPayHouse(tmpPayHouse);
            _UpdateTotalPay();
        }

        /// <summary>
        /// 设置住房贷款
        /// </summary>
        /// <param name="value"></param>
        private void _SetPayHouse(int value)
        {
            input_payHouse.text = value.ToString();
            _UpdateTotalPay();
        }

        /// <summary>
        /// 修改教育支出
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyPayEduc(string value)
        {
            var tmpPayEduc = 0;
            if(""!=value)
            {
                tmpPayEduc = int.Parse(value);
            }
            this.newInfor.initEducationLoan = tmpPayEduc;
            _UpdateTotalPay();
        }
        /// <summary>
        /// 修改购车支出
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyPayCar(string value)
        {
            var tmpPayCar = 0;
            if(""!=value)
            {
                tmpPayCar = int.Parse(value);
            }
            this.newInfor.initCarLoan = tmpPayCar;
            _UpdateTotalPay();
        }
        /// <summary>
        /// 修改银行卡支出
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyPayCard(string value)
        {
            var tmpPayCard = 0;
            if(""!=value)
            {
                tmpPayCard = int.Parse(value);
            }
            this.newInfor.initCardLoan = tmpPayCard;
            _UpdateTotalPay();
        }

        /// <summary>
        /// 修改生活必备支出
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyPayNess(string value)
        {
            var tmpPayNess = 0;
            if(""!=value)
            {
                tmpPayNess=int.Parse(value);
            }
            this.newInfor.initOtherSpend = tmpPayNess;
            _UpdateTotalPay();
        }

        private void _OnModifyPayChild(string value)
        {
            if(""== value)
            {
                //MessageHint.Show("生孩子费用不能为空");
                return;
            }

            this.newInfor.oneChildPrise = int.Parse(value);
            _UpdateTotalPay();
        }

        /// <summary>
        /// 修改住房抵押贷款
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyDebtHouse(string value)
        {
            if(value=="")
            {
                return;
            }
            this.newInfor.fixedHouseMortgages = int.Parse(value);
            _UpdateTotalPay();
        }


        /// <summary>
        /// 修改教育抵押贷款
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyDebtEduc(string value)
        {
            if (value == "")
            {
                return;
            }

            this.newInfor.fixedEducation = int.Parse(value);
            _UpdateTotalPay();
        }

        /// <summary>
        /// 修改购车抵押贷款
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyDebtCar(string value)
        {
            if(""==value)
            {
                return;
            }
            this.newInfor.fixedCarLoan = int.Parse(value);
            _UpdateTotalPay();
        }

        /// <summary>
        /// 修改信用卡抵押贷款
        /// </summary>
        /// <param name="value"></param>
        private void _OnModifyDebtCard(string value)
        {
            if(""==value)
            {
                return;
            }

            this.newInfor.fixedCardLoan = int.Parse(value);
            _UpdateTotalPay();
        }


        /// <summary>
        /// 关闭负债面板
        /// </summary>
        private Button btn_closeDebt;
        /// <summary>
        /// 确定负债支出
        /// </summary>
        private Button btn_sureDebt;
        
        /// <summary>
        /// 税金
        /// </summary>
        private InputField input_payTax;
        /// <summary>
        /// 住房抵押贷款利息
        /// </summary>
        private InputField input_payHouse;
        /// <summary>
        /// 每月的教育支出
        /// </summary>
        private InputField input_payEduc;
        /// <summary>
        /// 每月的购车支出
        /// </summary>
        private InputField input_payCar;
        /// <summary>
        /// 每月的信用卡支出
        /// </summary>
        private InputField input_payCard;
        /// <summary>
        /// 每月的生活必要支出
        /// </summary>
        private InputField input_payNess;
        /// <summary>
        /// 生孩子支出
        /// </summary>
        private InputField input_payChild;

        /// <summary>
        /// 住房抵押贷款
        /// </summary>
        private InputField input_DebtHouse;
        /// <summary>
        /// 教育金贷款
        /// </summary>
        private InputField input_DebtEduc;
        /// <summary>
        /// 购车抵押贷款
        /// </summary>
        private InputField input_DebtCar;
        /// <summary>
        /// 信用卡抵押贷款
        /// </summary>
        private InputField input_DebtCard;
        /// <summary>
        /// 总支出
        /// </summary>
        private Text txt_debt_totaldebt;
    }
}
