﻿using System;

namespace Client.UI
{
	public partial class UIFightroomWindow
	{
		class Layout
		{
			public static string btn_back="btnback";

			public static string img_player="imgplayer";
			//public static string img_player2="imgplayer2";
			//public static string img_player3="imgplayer3";
			//public static string img_player4="imgplayer4";

			public static string lb_roomid= "txt_roomid";

			public static string btn_ready="btn_ready";
			public static string btn_share="btn_share";

			/// <summary>
			/// The scroll rect. 聊天对话框
			/// </summary>
			public static string scrollRect="scrollmessage";

			public static string lb_chat = "txtname";

			public static string btn_sendChat="btn_sendmessage";

			public static string lb_input="inputmessage";
		}
	}
}

