﻿using System;

namespace Client.UI
{
	public partial class UILoadingNetGameWindow
	{
		class Layout
		{
			public static string progressBar = "progressBar";

			public static string img_role="role";

			public static string lb_name ="lbname";
		}
	}
}

