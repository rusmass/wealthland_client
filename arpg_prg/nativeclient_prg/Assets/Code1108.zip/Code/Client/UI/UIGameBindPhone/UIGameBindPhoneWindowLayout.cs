﻿using System;

namespace Client.UI
{
	public partial class UIGameBindPhoneWindow
	{
		class Layout
		{
			public static string inputPhone="inputphone";
			public static string inputIdentify="inputidentify";
			public static string inputScret="inputscret";
			public static string inputScretAgain="inputscretagain";

			public static string btn_getIndentify="btngetidentify";

		
			public static string btn_sureModify="btnsuremodify";

			public static string btn_close="btn_close";

			public static string img_word="img_word";

			public static string lb_bindtip="lb_bindtip";

			/// <summary>
			/// The image scretbg.输入密码
			/// </summary>
			public static string img_scretbg="scretbg";

		}
	}
}

