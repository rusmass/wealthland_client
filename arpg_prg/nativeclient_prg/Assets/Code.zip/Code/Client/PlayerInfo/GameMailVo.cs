﻿using System;

/// <summary>
///  邮箱数据单元
/// </summary>
public class GameMailVo
{
    public GameMailVo()
    {
    }

    public string title;
    public string content;
    /// <summary>
    /// The is read. 是否是已经读取了
    /// </summary>
    public bool isRead;
}
