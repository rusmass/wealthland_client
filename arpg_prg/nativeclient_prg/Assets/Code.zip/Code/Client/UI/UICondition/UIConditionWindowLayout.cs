﻿
using System;

namespace Client.UI
{
	public partial class UIConditionWindow
	{
		class Layout
		{
			public static string img_title="titleimg";
			public static string lb_title="txttitle";
			public static string lb_infor="infortxt";


			public static string btn_sure="tipbtn";


		}		
	}
}

