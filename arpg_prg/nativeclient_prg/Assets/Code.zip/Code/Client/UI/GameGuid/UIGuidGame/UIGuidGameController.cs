﻿using System;

namespace Client.UI
{
	public class UIGuidGameController : UIController<UIGuidGameWindow, UIGuidGameController>
	{
		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/newplayerguid/uinewguidgame.ab";

            }
		}

		public UIGuidGameController()
		{
		}
	}
}

