﻿using System;
using UnityEngine;

namespace Client.UI
{
	public class UIGuidRoomWindow : UIWindow<UIGuidRoomWindow, UIGuidRoomController>
	{
		public UIGuidRoomWindow()
		{
		}

		protected override void _Init (GameObject go)
		{
			
		}

		protected override void _OnShow ()
		{
			
		}

		protected override void _OnHide ()
		{
			
		}

		protected override void _Dispose ()
		{
			
		}
	}
}

