﻿using System;

namespace Client.UI
{
	public class UIGuidBorrowController : UIController<UIGuidBorrowWindow, UIGuidBorrowController>
	{
		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/newplayerguid/uinewguidborrow.ab"; ;
			}
		}

		public UIGuidBorrowController()
		{
            
		}
	}
}

