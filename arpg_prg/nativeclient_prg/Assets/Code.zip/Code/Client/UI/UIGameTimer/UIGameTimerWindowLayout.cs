﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client.UI
{
    partial class UIGameTimerWindow
    {
        class Layout
        {
            public static string lb_time = "lb_time";
        }
    }
}
