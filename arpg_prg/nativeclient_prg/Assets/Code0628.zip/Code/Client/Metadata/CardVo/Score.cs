﻿using System;

namespace Metadata
{
	[ExportAttribute(ExportFlags.ExportRaw)]
	public partial class Score : Template
	{
		public string des;
	}
}

