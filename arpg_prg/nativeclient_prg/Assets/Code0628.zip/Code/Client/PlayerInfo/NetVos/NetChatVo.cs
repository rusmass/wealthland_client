﻿using System;

namespace Client
{
	public class NetChatVo
	{
		public NetChatVo ()
		{
		}

		public string playerId;

		public string playerName;

		public string playerHead; 

		public string chat;

		/// <summary>
		/// The sex. 性别 0 nv  1 nan
		/// </summary>
		public int sex=0;

		/// <summary>
		/// The send time.发言时间
		/// </summary>
		public string sendTime;
	}
}

