using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class StringDTO
{
	public string value;
	public StringDTO ()
	{
	}
	public StringDTO(string v){
		this.value = v;
	}
}


