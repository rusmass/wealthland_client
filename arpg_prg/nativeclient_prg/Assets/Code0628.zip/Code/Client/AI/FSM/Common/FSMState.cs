﻿using System;
using Client.Unit;

namespace Client.UnitFSM
{
	public class FSMState : FSM.State
	{
		public FSMState (Room content, FSMStateType stateType) 
			:base (content)
		{
			_stateType = stateType;
		}

		public FSMStateType StateType { get { return _stateType; } }
		private FSMStateType _stateType;
	}
}

