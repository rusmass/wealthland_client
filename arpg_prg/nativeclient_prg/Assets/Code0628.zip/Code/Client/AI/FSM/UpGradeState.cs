﻿using System;
using Client.Unit;
using Client.UI;

namespace Client.UnitFSM
{
    public class UpGradeState : FSMState
    {
        public UpGradeState(Room content)
            : base(content, FSMStateType.UpGradeState)
        {
        }

        protected override Core.FSM.FiniteStateMachine<Room>.State _DoEvent(Core.FSM.Event e)
        {
            switch ((FSMEventType)e.ID)
            {
                case FSMEventType.StayEvent:
                    return new StayState(_Content);
                case FSMEventType.WalkEvent:
                    return new WalkState(_Content);

                default:
                    break;
            }

            return this;
        }

        public override void Enter(Core.FSM.Event e, Core.FSM.FiniteStateMachine<Room>.State lastState)
        {
            var func = (e as UpGradeEvent).lpfnUpGradeToInner;
            func();

            CardManager.Instance.OpenCard((int)SpecialCardType.UpGradType);
        }

        protected override void _OnExit(Core.FSM.Event e, Core.FSM.FiniteStateMachine<Room>.State nextState)
        {
            
        }

        protected override Core.FSM.FiniteStateMachine<Room>.State _DoTick(float deltaTime)
        {
            return this;
        }
    }
}

