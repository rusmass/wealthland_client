﻿using System;

namespace Client
{
	public enum CareerType
	{
		None=100000,
		Doctor,
		Lawyer,
		SaleManager,
		ItProgramer,
		Driver,
		Security
	}
}

