﻿
namespace Client
{
    public enum ObjectType
    {
        Invalid = -1,
        Npc,
        Player,
        Ghost,
    }
}
