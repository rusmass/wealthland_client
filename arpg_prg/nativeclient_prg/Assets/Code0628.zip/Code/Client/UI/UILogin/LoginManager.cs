﻿using System;

namespace Client.UI
{
	public class LoginManager
	{
		
	}
}

