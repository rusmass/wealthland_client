﻿using System;

namespace Client.UI
{
	public partial class UISaleInforWindow
	{
		class Layout
		{
			public static string content_infor="content_infor";
			public static string btn_close="btn_close";
		}
	}
}

