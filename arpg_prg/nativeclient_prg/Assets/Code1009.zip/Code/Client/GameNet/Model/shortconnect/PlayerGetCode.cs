﻿using System;

namespace GameNet
{
    /// <summary>
    /// 获取短信验证码是，发送是手机号数据
    /// </summary>
    public class PlayerGetCode
	{
		public string phone;
	}
}

