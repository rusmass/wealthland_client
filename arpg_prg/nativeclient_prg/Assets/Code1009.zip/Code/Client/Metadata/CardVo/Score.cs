﻿using System;

namespace Metadata
{
    /// <summary>
    /// 分数
    /// </summary>
    [ExportAttribute(ExportFlags.ExportRaw)]
	public partial class Score : Template
	{
		public string des;
	}
}

