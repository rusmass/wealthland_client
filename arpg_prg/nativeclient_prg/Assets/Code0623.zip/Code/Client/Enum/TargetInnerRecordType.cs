﻿using System;

namespace Client
{
	public enum TargetInnerRecordType
	{
		Null,
		Flow,
		Time,
		Quality
	}
}

