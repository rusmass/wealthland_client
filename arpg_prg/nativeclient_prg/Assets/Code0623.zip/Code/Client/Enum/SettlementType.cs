﻿namespace Client
{
	public enum SettlementType
	{
		BigOpportunityEnum,
		SmallOpportunityEnum,
		RiskEnum,
		FateEnum,
		InvestmentEnum,
		RichLeisureEnum,
		QualityEnum
	}
}