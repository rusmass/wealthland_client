﻿using System;

namespace GameNet
{
	public class CheckVersion
	{
		public string versionCode;
	}
}

