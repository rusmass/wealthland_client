﻿using System;

namespace Client.UI
{
	public partial class UISelectRoleWindow
	{
		class Layout
		{
			public static string img_role="roleimg";
			public static string btn_clickingame="btnclickin";
			public static string img_rotate="rotationimg";
			public static string btn_selectrole="btnselectrole";
			public static string anim_rotation="zhuanpan";


			public static string img_infor="image_infor";
			public static string lb_name="name";
			public static string lb_age="age";
			public static string lb_career="career";
			public static string lb_cashFlow="cashflow";
			public static string lb_payment="payment";
			public static string lb_income="income";
			public static string lb_infor="lbinfor";

			public static string selectrole="selectrole";
		}
	}
}

