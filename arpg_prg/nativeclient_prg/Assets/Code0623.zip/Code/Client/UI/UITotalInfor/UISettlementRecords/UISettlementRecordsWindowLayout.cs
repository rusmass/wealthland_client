﻿using UnityEngine;
using System.Collections;
using System;

namespace Client.UI
{
	public partial class UISettlementRecordsWindow
	{
		class Layout
		{
			/// <summary>
			/// cenrter
			/// </summary>
			public static string txt = "txt";
			public static string txtBtn = "txtBtn";
			public static string txtNum = "txtNum";

			public static string txtLoanNum = "txtLoanNum";
			public static string txtLoanNum2 = "txtLoanNum2";
			public static string txtLoanIntroduce = "txtLoanIntroduce";

			public static string txtlaborNum = "txtlaborNum";
			public static string txtLaborIntroduce = "txtLaborIntroduce";

			public static string txtCardNum = "txtCardNum";
			public static string txtCardNum2 = "txtCardNum2";
			public static string txtCardIntroduce = "txtCardIntroduce";

			/// <summary>
			/// top
			/// </summary>
			public static string closebtn = "closebtn";
		}
	}
}

