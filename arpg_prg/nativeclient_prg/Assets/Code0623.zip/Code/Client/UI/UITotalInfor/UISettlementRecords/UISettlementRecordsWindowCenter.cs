﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Client.UI
{
	public partial class UISettlementRecordsWindow
	{

		private void _OnInitCenter(GameObject go)
		{
//			txt_top = go.GetComponentEx<Text>(Layout.txt);
//			txt_btn = go.GetComponentEx<Text>(Layout.txtBtn);
//			txt_Num = go.GetComponentEx<Text>(Layout.txtNum);
//
//			txt_LoanNum = go.GetComponentEx<Text>(Layout.txtLoanNum);
//			txt_LoanNum2 = go.GetComponentEx<Text>(Layout.txtLoanNum2);
//			txt_LoanIntroduce = go.GetComponentEx<Text>(Layout.txtLoanIntroduce);
//
//			txt_LaborNum = go.GetComponentEx<Text>(Layout.txtlaborNum);
//			txt_LaborIntroduce = go.GetComponentEx<Text>(Layout.txtLaborIntroduce);
//
//			txt_CardNum = go.GetComponentEx<Text>(Layout.txtCardNum);
//			txt_CardNum2 = go.GetComponentEx<Text>(Layout.txtCardNum2);
//			txt_CardIntroduce = go.GetComponentEx<Text>(Layout.txtCardIntroduce);
		}

		private void _OnShowCenter()
		{
			
		}
	
//		private Text txt_top;
//		private Text txt_btn;
//		private Text txt_Num;
//
//		private Text txt_LoanNum;
//		private Text txt_LoanNum2;
//		private Text txt_LoanIntroduce;
//
//		private Text txt_LaborNum;
//		private Text txt_LaborIntroduce;
//
//		private Text txt_CardNum;
//		private Text txt_CardNum2;
//		private Text txt_CardIntroduce;
	}
}

