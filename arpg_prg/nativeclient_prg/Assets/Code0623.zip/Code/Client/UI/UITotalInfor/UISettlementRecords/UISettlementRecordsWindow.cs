﻿using UnityEngine;
using System.Collections;
using System;

namespace Client.UI
{
	public partial class UISettlementRecordsWindow : UIWindow<UISettlementRecordsWindow,UISettlementRecordsController> {

		public UISettlementRecordsWindow()
		{
			
		}

		protected override void _Init (GameObject go)
		{
			
		}

		protected override void  _OnShow()
		{
			
		}

		protected override void _OnHide()
		{
			
		}

		protected override void _Dispose()
		{
			
		}
	}
}
