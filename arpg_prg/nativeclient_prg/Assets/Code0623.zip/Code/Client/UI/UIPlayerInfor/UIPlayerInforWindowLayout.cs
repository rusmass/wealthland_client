﻿
using System;

namespace Client.UI
{
	public partial class UIPlayerInforWindow
	{
		class Layout
		{
			public static string input_name="imput_name";

			public static string btn_man="btn_man";

			public static string btn_woman="btn_woman";

			public static string btn_head1="btn_head1";

			public static string btn_head2="btn_head2";

			public static string btn_head3="btn_head3";

			public static string btn_head4="btn_head4";

			public static string img_head="headimg";

			public static string btn_headselect="btn_headselect";

			public static string lb_tip="tiptxt";

			public static string btn_close="closebtn";

			public static string btn_sure="surebtn";


			public static string img_title="imgtitle";

			/// <summary>
			/// The text title. 标题
			/// </summary>
			public static string txt_title="txt_title";
			
		}
	}
}

