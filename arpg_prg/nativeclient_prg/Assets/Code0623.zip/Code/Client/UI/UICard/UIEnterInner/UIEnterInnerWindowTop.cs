﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Client.UI
{
	public partial class UIEnterInnerWindow
	{
		private void _InitTop(GameObject go)
		{
//			_titleTxt = go.GetComponentEx<Text> (Layout.lb_title);
			_btnClose = go.GetComponentEx<Button> (Layout.btn_sure);
		}

		private void _OnShowTop()
		{
//			_titleTxt.text = "结算日";
			EventTriggerListener.Get (_btnClose.gameObject).onClick += _onSureHandler;
//			if (!_playerManager.IsHostPlayerTurn())
//			{
//				var waitTime = MathUtility.Random(2, 5);
//				_timer = new Counter(waitTime);
//			}

		}

		private void _OnHideTop()
		{
			EventTriggerListener.Get (_btnClose.gameObject).onClick -= _onSureHandler;
		}

		private void _onSureHandler(GameObject go)
		{
			Audio.AudioManager.Instance.BtnMusic ();
			if (_playerManager.IsHostPlayerTurn())
			{
				//TODO HostPlayer Behaviour
				_controller.HandlerCardData ();
//				Client.Unit.BattleController.Instance.Send_RoleSelected (1);
//				Client.Unit.BattleController.Instance.Send_UpGradeFinish(true);
				_controller.setVisible(false);

//				var tmpController = UIControllerManager.Instance.GetController<UIConditionWindowController> ();
//				tmpController.showConditionType = 1;
//				tmpController.setVisible (true);
			}
		}

		private void _OnTopTick(float deltaTime)
		{
//			if (null != _timer && _timer.Increase(deltaTime))
//			{
//				_timer = null;
//				_controller.HandlerCardData ();
//				Client.Unit.BattleController.Instance.Send_RoleSelected (1);
//				_controller.setVisible(false);
//			}
		}


		// set the txt context
		public void setTitle (string str)
		{
//			_titleTxt.text = str;
		}

//		private Text _titleTxt;	
		private Button _btnClose;

		private Counter _timer;
		private PlayerManager _playerManager = PlayerManager.Instance;
	}
}

