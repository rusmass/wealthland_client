﻿using System;

namespace Client
{
	
	public class CapitalVo
	{
		// 总资产的数据，记录每一岁的资产情况 年龄和资产额

		public int age;
		public float captical;
	}
}

