﻿using System;

namespace Client
{
	public class FateSaleFiexdVo
	{
		//命运卖资产数据单元

		public int id;

		public int belongsTo;

		public string title;
		public float payment;
		public float mortgage;
		public float saleMoney;
		public float changeMoney;
		public float income;
		public float quality;
		public int baseNum;
		public bool isSlected=true;


	}
}

