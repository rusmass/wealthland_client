﻿using System;

namespace Client
{
	public class NetChooseRoleInfor
	{
		public NetChooseRoleInfor ()
		{
		}

		public string nickName="";
		public string playerId="";
		public int careerId=0;

	}
}

