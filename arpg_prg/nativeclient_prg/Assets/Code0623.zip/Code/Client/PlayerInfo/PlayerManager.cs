﻿using System;
using Client.Unit;
using Metadata;
using System.Collections.Generic;
using UnityEngine;

namespace Client
{
	public class PlayerManager
	{
		protected PlayerManager ()
		{
			
			playerInitList = new List<PlayerInitData> ();

			var template = MetadataManager.Instance.GetTemplateTable<PlayerInitData> ();
			var it = template.GetEnumerator ();
			while (it.MoveNext ()) 
			{				
				var value = it.Current.Value as PlayerInitData;
				playerInitList.Add(value);			
			}
//            _hostPlayerInfo = new PlayerInfo();
//			_hostPlayerInfo.SetPlayerInitData (playerInitList[0]);
//			_hostPlayerInfo.playerID = "11"; 
//			_hostPlayerInfo.playerName = "张三";
//
//			var battlecontroller = Client.UIControllerManager.Instance.GetController<Client.UI.UIBattleController> ();
//			if (null!=battlecontroller) 
//			{
//				battlecontroller.SetCashFlow ((int)_hostPlayerInfo.totalMoney);
//			}
//            _players[0] = _hostPlayerInfo;

        }


		public void SetPlayerHero(PlayerInitData playerdata, int heroIndex , string roleName)
		{
			_hostPlayerInfo = new PlayerInfo();
			_hostPlayerInfo.SetPlayerInitData (playerdata);
			_hostPlayerInfo.playerID = "111"; 
			// 2016-10-28 zll fix name
			_hostPlayerInfo.playerName = roleName;

			var battlecontroller = Client.UIControllerManager.Instance.GetController<Client.UI.UIBattleController> ();
			if (null!=battlecontroller) 
			{
				battlecontroller.SetCashFlow ((int)_hostPlayerInfo.totalMoney);
			}
			_players[0] = _hostPlayerInfo;

			_seletcedArr [heroIndex] = 0;

			_SelectRandomNpc (1);
			_SelectRandomNpc (2);
			_SelectRandomNpc (3);

			_players[1].playerID = "222"; 
			_players[2].playerID = "334";
			_players[3].playerID = "447";

			Room.Instance.SetPlayerModel (_players);
		}

		public void SetNetPlayerInfor( List<PlayerInfo> tmpList)
		{

			if (_players [0] == null && _players [1] == null && _players [2] == null && _players [3] == null)
			{
				for (int i = 0; i < _players.Length; i++)
				{
					_players [i] = tmpList [i];
				}

				_hostPlayerInfo = _players [0];

				var battlecontroller = Client.UIControllerManager.Instance.GetController<Client.UI.UIBattleController> ();
				if (null!=battlecontroller) 
				{
					battlecontroller.SetCashFlow ((int)_hostPlayerInfo.totalMoney);
				}
			}
			else
			{
				
			}

			Room.Instance.SetPlayerModel (_players);
		}

		private void _SelectRandomNpc(int npcNum)
		{
			var range = 5;
			var tmpIndex = MathUtility.Random (0,range);

			if (npcNum < 3)
			{
				while (_seletcedArr[tmpIndex] == 0)
				{
					tmpIndex = MathUtility.Random (0,range);
				}
			}
			else
			{
				for (var i = 0; i < _seletcedArr.Length; i++)
				{
					if (_seletcedArr [i] != 0)
					{
						tmpIndex = i;
						break;
					}
				}
			}
			_seletcedArr [tmpIndex] = 0;
			_players[npcNum] = new PlayerInfo();
			_players [npcNum].SetPlayerInitData (playerInitList[tmpIndex]); 
		}


        private PlayerInfo _hostPlayerInfo;
        public PlayerInfo HostPlayerInfo
        {
            get
            {
                return _hostPlayerInfo;
            }
        }

        private PlayerInfo[] _players = new PlayerInfo[4];
        public PlayerInfo[] Players
        {
            get
            {				
                return _players;
            }
        }

        public bool IsHostPlayerTurn()
        {
            var index = BattleController.Instance.CurrentPlayerIndex;
            if (index >= _players.Length)
            {
                Console.Error.WriteLine("[PlayerManager.IsHostPlayerTurn] error!");
            }
            var player = _players[index];
            return player.playerID == _hostPlayerInfo.playerID;
        }

		public PlayerInfo GetPlayerInfo(string playerID)
        {
            for (int i = 0; i < _players.Length; ++i)
            {
                if (_players[i].playerID == playerID)
                {
                    return _players[i];
                }
            }

            return null;
        }
		private int[] _seletcedArr = { -1, -1, 0, 0, -1, -1 };
		private List<PlayerInitData> playerInitList;
		private static PlayerManager _manager;
		public static PlayerManager Instance
		{
			get
			{
				if(null == _manager)
				{					
					_manager= new PlayerManager();
				}

				return _manager;
			}
		}

		public void Dispose()
		{
			_hostPlayerInfo = null;

			_players = null;
			_manager = null;
		}


		public void ReStartGame()
		{
			for (var i = 0; i < _players.Length; i++)
			{
				var tmpPlayerInfor = new PlayerInfo ();
				var player=_players[i];

				if (null != player)
				{
					for (var j = 0; j < playerInitList.Count; j++)
					{
						var tmpInitData = playerInitList[j];
						if (null != tmpInitData)
						{							
							if (player.career == tmpInitData.careers)
							{
								tmpPlayerInfor.SetPlayerInitData (tmpInitData);
								tmpPlayerInfor.playerName = player.playerName;
								_players [i] = null;
								_players[i] = tmpPlayerInfor;
								break;
							}
						}

					
					}
				}
			}

			_players [0].playerID = "11";
			_players [1].playerID = "22";
			_players [2].playerID = "33";
			_players [3].playerID = "44";

			_hostPlayerInfo = _players [0];
		}
	}
}

