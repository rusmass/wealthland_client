﻿using System;

namespace Client.GameFSM
{
	public enum FSMEventType
	{
		None,
		LoginEvent,
		SelectRoleEvent,
		ReStartGameEvent,
		GameHallEvent,
		LoadingStateEvent,
		NetSelectRoleEvent,
	}

	public class FSMEvent : Core.FSM.Event
	{
		public FSMEvent(FSMEventType type)
			: base((int)type)
		{
		}
	}

	public class LoginEvent : FSMEvent
	{
		public LoginEvent ()
			:base(FSMEventType.LoginEvent)
		{
		}
	}

	public class SelectRoleEvent : FSMEvent
	{
		public SelectRoleEvent()
			:base(FSMEventType.SelectRoleEvent)
		{
			
		}
	}

	/// <summary>
	/// Re start game event.游戏重新开始
	/// </summary>
	public class ReStartGameEvent:FSMEvent
	{
		public ReStartGameEvent()
			:base(FSMEventType.ReStartGameEvent)
		{
			
		}
	}

	public class GameHallEvent:FSMEvent
	{
		public GameHallEvent():base(FSMEventType.GameHallEvent)
		{
			
		}
	}

	public class NetSelectRoleEvent:FSMEvent
	{
		public NetSelectRoleEvent():base(FSMEventType.NetSelectRoleEvent)
		{
			
		}
	}

	public class LoadingEvent:FSMEvent
	{
		public LoadingEvent():base(FSMEventType.LoadingStateEvent)
		{

		}
	}
}

