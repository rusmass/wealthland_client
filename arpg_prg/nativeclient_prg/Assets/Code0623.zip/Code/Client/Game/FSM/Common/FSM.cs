﻿using System;
using Core.FSM;

namespace Client.GameFSM
{
	public class FSM : FiniteStateMachine<Game>
	{
		public FSM(Game content)
			:base(content)
		{
			_enterStateConstructor = _CreateEnterState;
		}

		public FSMStateType CurrentStateType
		{
			get 
			{
				FSMState state = _currentState as FSMState;
				if (null != state) 
				{
					return state.StateType;
				}

				return FSMStateType.None;
			}
		}

		private FSMState _CreateEnterState()
		{
			return new StartState (_Content);
		}
	}
}

