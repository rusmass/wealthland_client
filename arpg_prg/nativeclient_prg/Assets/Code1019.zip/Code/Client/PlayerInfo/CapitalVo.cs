﻿using System;

namespace Client
{
    /// <summary>
    /// 总资产的数据，记录每一岁的资产情况 年龄和资产额
    /// </summary>
    public class CapitalVo
    {
        // 
        public int age;
        public float captical;
    }
}


