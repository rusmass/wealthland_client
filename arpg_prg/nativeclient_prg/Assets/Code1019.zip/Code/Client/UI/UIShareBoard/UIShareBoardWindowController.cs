﻿using System;

namespace Client.UI
{
    /// <summary>
    /// 游戏大厅分享窗口
    /// </summary>
	public class UIShareBoardWindowController:UIController<UIShareBoardWindow,UIShareBoardWindowController>
	{
		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/gameshareboard.ab";
			}
		}

        /// <summary>
        /// 未引用
        /// </summary>
		public UIShareBoardWindowController ()
		{
		}
	}
}

