﻿using System;

namespace Client
{
    /// <summary>
    /// 未引用    ，负债信息数据单元 每个年龄上获得的数据
    /// </summary>
	public class PlayerDebtInfor
    {
        // 

        // 负债信息
        public float extendDebt;
        public float baseDebt;
        //记录负债的年龄
        public float age;
    }
}


