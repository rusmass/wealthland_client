﻿namespace Client
{
    /// <summary>
    ///  结账的类型，未引用
    /// </summary>
	public enum SettlementType
	{
		BigOpportunityEnum,
		SmallOpportunityEnum,
		RiskEnum,
		FateEnum,
		InvestmentEnum,
		RichLeisureEnum,
		QualityEnum
	}
}