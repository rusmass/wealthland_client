﻿using System;

namespace Client.UI
{
	public partial class UIQuitFightGameWindow
	{
		class Layout
		{
			public static string lb_tip="tipTxt";

			public static string lb_number="numtip";

			public static string btn_sure = "knowbtn";

			public static string btn_cancle = "tipbtn";

			public static string lb_lefttime="lb_lefttime";
		}
	}
}

