﻿using System;

namespace Client.UI
{
	public partial class UIInnerSelectFreeWindow
	{
		class Layout
		{
			public static string btn_investment="btn_investment";
			public static string btn_relax="btn_relax";
			public static string btn_quality="btn_quality";

			public static string lb_clock="lb_time";
		}
	}
}

