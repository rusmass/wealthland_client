﻿using System;

namespace Client
{
	public class SaleRecordVo
	{
		public string title;
		public float price;
		public int number;
		public float mortage=-1;
		public float saleMoney;
		public float income;
		public float quality;
		public float getMoney;
	}
}

