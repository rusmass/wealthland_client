﻿using System;

namespace Client
{
	public class InforRecordVo
	{
		public int index;

		public string title;

		public float num;
	}
}

