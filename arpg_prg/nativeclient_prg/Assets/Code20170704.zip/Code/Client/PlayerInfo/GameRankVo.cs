﻿using System;

namespace Client
{
	public class GameRankVo
	{
		public GameRankVo ()
		{
		}

		public int rankIndex=0;
		public string playerName="";
		public string headPath="";
		public string rankTip="";

	}
}

