﻿using System;

namespace Client.UnitFSM
{
	public enum FSMStateType
	{
		None,
		StayState,
		RollState,
		WalkState,
        SelectState,
		GiveUpState,
        UpGradeState,
        SuccessState,
	}
}

