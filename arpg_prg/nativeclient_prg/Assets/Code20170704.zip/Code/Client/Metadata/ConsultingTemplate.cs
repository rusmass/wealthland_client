﻿using System;

namespace Metadata
{
	[ExportAttribute(ExportFlags.ExportRaw)]
	public partial  class ConsultingTemplate :Template
	{
		public string questionGroupName;

		public string questionName;
		
		public string questionDescribe;
	}
}

