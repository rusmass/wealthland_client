﻿using System;

namespace Metadata
{
    [Export(ExportFlags.ExportRaw)]
    public partial class StageOuterPoint : Template
    {
        public string action;

        public bool IsCheckDay()
        {
            return action.Equals("CheckDayAction");
        }
    }
}
