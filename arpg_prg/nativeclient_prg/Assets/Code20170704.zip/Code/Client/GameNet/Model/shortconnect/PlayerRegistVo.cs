﻿using System;

namespace GameNet
{
	public class PlayerRegistVo
	{
		//手机号码
		public string phone;
		//验证码
		public string code;
		//密码
		public string password;
	}
}

