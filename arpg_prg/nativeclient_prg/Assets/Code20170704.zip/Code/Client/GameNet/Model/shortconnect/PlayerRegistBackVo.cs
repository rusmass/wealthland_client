﻿using System;

namespace GameNet
{
	public class PlayerRegistBackVo
	{
		/// <summary>
		/// The status 返回值信息  0成功 ,1失败了 
		/// </summary>
		public int status;
		/// <summary>
		/// The message. 失败后的提示信息
		/// </summary>
		public string msg;
	}
}

