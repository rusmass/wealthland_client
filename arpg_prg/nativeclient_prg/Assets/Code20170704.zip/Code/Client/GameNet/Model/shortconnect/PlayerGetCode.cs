﻿using System;

namespace GameNet
{
	public class PlayerGetCode
	{
		public string phone;
	}
}

