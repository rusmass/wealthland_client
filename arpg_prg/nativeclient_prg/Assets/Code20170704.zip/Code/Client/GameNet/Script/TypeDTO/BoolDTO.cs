using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class BoolDTO
{
	public bool value;
	public BoolDTO (){
		
	}
	public BoolDTO(bool v){
		this.value = v;
	}
}

