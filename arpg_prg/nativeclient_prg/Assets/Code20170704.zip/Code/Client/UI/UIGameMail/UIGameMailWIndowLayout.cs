﻿using System;

namespace Client.UI
{
	public partial class UIGameMailWindow
	{
		class Layout
		{
			public static string btn_title="btn_gonggao1";

			public static string txt_title="txt_title";

			public static string txt_content="txt_content";

			public static string btn_close="btn_close";

			public static string btn_receive="surebtn";

			public static string btn_delete="deletebtn";

			public static string btn_deleteAll="deleteallbtn";

			public static string btn_receivedAll="receiveallbtn";
		}
	}
}

