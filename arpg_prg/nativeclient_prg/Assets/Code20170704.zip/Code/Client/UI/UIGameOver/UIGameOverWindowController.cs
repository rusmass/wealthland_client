﻿using System;

namespace Client.UI
{
	public class UIGameOverWindowController:UIController<UIGameOverWindow,UIGameOverWindowController>
	{
		protected override string _windowResource {
			get {
				return "prefabs/ui/scene/uiovergamenew.ab";
			}
		}

		protected override void _OnLoad ()
		{
			
		}

		protected override void _OnHide ()
		{
			
		}

		protected override void _OnShow ()
		{
			
		}

		protected override void _Dispose ()
		{
			
		}

		public override void Tick (float deltaTime)
		{
			var window = _window as UIGameOverWindow;
			if (null != window && this.getVisible ())
			{
				window.Tick (deltaTime);
			}
		}


		public void ShowOverScene()
		{
			var window = _window as UIGameOverWindow;
			if (null != window && this.getVisible ())
			{
				window.ShowOverScene ();
			}
		}

		public void HideOverScene()
		{
			var window = _window as UIGameOverWindow;
			if (null != window && this.getVisible ())
			{
				window.HideOverScene ();
			}
		}

	}
}

