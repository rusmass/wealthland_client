﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Client.UI
{
	public partial class UIGameSetWindow
	{
		private void _OnInitTop(GameObject go)
		{
			
		}


		
	}
}

