﻿using System;

namespace Client.UI
{
	public partial class UIHeroInforWindow
	{
		// 人物信息加载

		class Layout
		{
			public static string img_hero="heroimg";

			public static string lb_name="nametitle";
			public static string lb_age="agetitle";
			public static string lb_career="careertitle";
			public static string lb_money = "moneytitle";
			public static string lb_balance="balancetitle";
			public static string lb_debt="debttitle";

			public static string lb_txt="/txt";

			public static string lb_nonlabincome="income";
			public static string lb_totalincome="totalincome";
			public static string lb_timescore="timescore";
			public static string lb_quality="qualityscore";
			public static string lb_payment="debtscore";
			public static string lb_totolmoney="totalmoney";
		}
	}
}

