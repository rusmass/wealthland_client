﻿using UnityEngine;
using System.Collections;
using System;

namespace Client.UI
{
	public partial class UILoadingWindow
	{
		class Layout 
		{
			public static string progressBar = "progressBar";
		}
	}
}
