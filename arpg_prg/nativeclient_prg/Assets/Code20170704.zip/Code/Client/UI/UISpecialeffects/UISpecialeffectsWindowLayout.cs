﻿using UnityEngine;
using System.Collections;

namespace Client.UI
{

	public partial class UISpecialeffectsWindow
	{
		class Layout
		{
			public const string HeadImagePerfab = "HeadImagePerfab";
			public const string HeadTextPerfab = "HeadTextPerfab";
		}
	}
}
