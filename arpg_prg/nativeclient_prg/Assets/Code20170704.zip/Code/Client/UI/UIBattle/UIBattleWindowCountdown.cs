﻿using System;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

namespace Client.UI
{
	public partial class UIBattleWindow
	{
		private void _OnInitCountdown(GameObject go)
		{
			_imgbuttonbg = go.GetComponentEx<Image> (Layout.img_btnbg);		

			img_roundTip = go.GetComponentEx<Image> (Layout.img_roundTip);
			lb_roundTip = go.GetComponentEx<Text> (Layout.lb_roundtip);
			lb_roundPlayer = go.GetComponentEx<Text> (Layout.lb_roundPlayer);
		}


		private void _OnShowCountdown()
		{
			//_imgbuttonbg.SetActiveEx (false);

			if (null != _imgbuttonbg)
			{
				if (_imgbuttonbg.IsActive () == false) 
				{
					_imgbuttonbg.SetActiveEx (true);
				}
			}
			_tmpCountImg.SetActiveEx(false);
		
		}

		/// <summary>
		/// Shows the stay round tip.显示哪个玩家在玩
		/// </summary>
		public void ShowStayRoundTip()
		{
			img_roundTip.SetActiveEx (true);



			var tmpStr = "";

			if (PlayerManager.Instance.IsHostPlayerTurn())
			{
				tmpStr = "轮到您了，请掷骰子";
//				lb_roundTip.text =string.Format("第{0}回合",_currentTurnCount+1);
			}
			else
			{
				tmpStr = string.Format ("当前轮到<color=#00f1a4>{0}</color>进行操作",_currentPlayer.playerName);
//				lb_roundTip.text =string.Format("第{0}回合",_currentTurnCount);
			}

			lb_roundPlayer.text = tmpStr;

			var sequence = DOTween.Sequence ();
			sequence.Append (img_roundTip.transform.DOLocalMoveX (img_roundTip.rectTransform.localPosition.x, 2.5f));
			sequence.AppendCallback (HideStayRoundTip);

		}

		/// <summary>
		/// Hides the stay round tip.隐藏玩家提示面板
		/// </summary>
		private void HideStayRoundTip()
		{
			img_roundTip.SetActiveEx (false);
		}


		public void _OnHideCountdown()
		{
			if (null != _imgbuttonbg)
			{
				_imgbuttonbg.DestroyEx ();
			}
		

			if (null != _tmpCountImg)
			{
				_tmpCountImg.gameObject.DestroyEx ();
			}
		}


		private string _countdownPath = "share/atlas/battle/daoshu/{0}.ab";
//		private int _currentCount = 3;



		private Image _imgbuttonbg;
		private Image _tmpCountImg;

		private Image img_roundTip;
		private Text  lb_roundTip;
		private Text  lb_roundPlayer;
	}
}

