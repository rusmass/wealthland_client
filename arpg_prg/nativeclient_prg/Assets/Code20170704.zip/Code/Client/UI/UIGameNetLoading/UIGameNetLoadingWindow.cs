﻿using System;
using UnityEngine;


namespace Client.UI
{
	public class UIGameNetLoadingWindow:UIWindow<UIGameNetLoadingWindow,UIGameNetLoadingWindowController>
	{
		public UIGameNetLoadingWindow ()
		{
		}

		protected override void _Init (GameObject go)
		{
			
		}

		protected override void _OnShow ()
		{
			
		}

		protected override void _OnHide ()
		{
			
		}

		protected override void _Dispose ()
		{
			
		}
	}
}

