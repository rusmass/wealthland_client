﻿using System;

namespace Client
{
	public enum BaseDebtType
	{
		None=100000,
		HouseDebt,
		EducationDebt,
		CarDebt,
		CardDebt,
		AdditionDebt,

		OtherDebt,
		InitTxtDebt,
		GiveChild
	}
}

