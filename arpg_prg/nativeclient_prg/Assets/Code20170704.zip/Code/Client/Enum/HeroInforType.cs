﻿using System;

namespace Client
{
	public enum HeroInforType
	{
		Null,
		HeroInfor,
		TargetInfor,
		BalanceIncomeInfor,
		DebtInfor,
		SaleInfor,
		CheckOutInfor
	}
}

