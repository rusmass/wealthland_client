﻿using Core;
using System;
using UnityEngine;

namespace Client
{
	public class GameSettings
	{
		private GameSettings ()
		{
			
		}

		public static readonly GameSettings Instance = new GameSettings();
	}
}

