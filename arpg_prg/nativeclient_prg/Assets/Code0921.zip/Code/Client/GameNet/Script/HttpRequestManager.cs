﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

using System;
using System.Net;
using System.Net.Security;
using System.IO;
using System.Text;
//using System.IO.Compression;
using System.Security.Cryptography.X509Certificates;
using System.Collections.Generic;

using LitJson;
using GameNet;
using Client;

public class HttpRequestManager : MonoBehaviour
{
    /// <summary>
    /// 游戏反馈后返回信息的
    /// </summary>
	public const string Type_FeedBack="feedback";

    /// <summary>
    /// 处理登录返回消息
    /// </summary>
	public const string Type_LoginBack="loginback";
    /// <summary>
    /// 处理注册返回消息
    /// </summary>
	public const string Type_RegistBack = "registback";
    /// <summary>
    /// 注册修改密码返回的消息
    /// </summary>
	public const string Type_ModifyBack = "modifyback";
    /// <summary>
    /// 修改获取验证码返回的消息
    /// </summary>
	public const string Type_GetCodeBack="getcodeback";
    /// <summary>
    /// 请求游戏版本号返回的消息
    /// </summary>
	public const string Type_GetVersionBack="backversion";
    /// <summary>
    /// 查看游戏服务器后返回的消息，暂时屏蔽服务器功能
    /// </summary>
	public const string Type_GetServerBack ="backserver";
    /// <summary>
    /// 创建角色后返回的消息
    /// </summary>
	public const string Type_GetPlayerInforBack = "backplayerinfor";
    /// <summary>
    /// 上传图像后返回的数据
    /// </summary>
	public const string Type_UploadImgBack = "backuploadimg";
    /// <summary>
    /// 绑定手机号后返回的消息
    /// </summary>
	public const string Type_blindPhone = "blindPhone";
    /// <summary>
    /// 检测手机号是否可绑定返回的消息
    /// </summary>
	public const string Type_CheckPhone = "chenckphonenumber";
    
    /// <summary>
    /// 处理获取游戏公告后返回的消息
    /// </summary>
	public const string Type_NoticeBack = "NoticeBack";

	// Use this for initialization
	void Start ()
	{
	}

	void Awake()
	{
		_instance = this;
	}
	
	// Update is called once per frame
	void Update ()
	{
	
	}

	/// <summary>
    /// Http Get方法，通过请求地址，和请求参数，确定请求的数据。通过type类型，和callBack，确定对的处理函数和应用的回调函数
    /// </summary>
    /// <param name="url"></param>
    /// <param name="getData"></param>
    /// <param name="type"></param>
    /// <param name="callback"></param>
    /// <returns></returns>
	IEnumerator Get(string url,string getData , string type ,Action callback=null) 
	{		
		Debug.Log (url+getData);
		var idfen = false;
		if (getData != "")
		{
			
			getData = "jsonString=" + WWW.EscapeURL (getData);//Encoding.UTF8.GetBytes();
			idfen = true;
		}
		WWW www;
		if(idfen==false)
		{
			www = new WWW (url+getData);
		}
		else
		{
			//getData
			Debug.Log (url+getData);
			www= new WWW (url+getData);
		}
		//www= new WWW ("http://59.110.29.41:8080/RichLife/account/player/getCode?jsonString=%7B%22phone%22%3A%2218618399063%22%7D");
		yield return www;

		if (www.error != null) 
		{
			Debug.Log("error is :"+ www.error);
		} 
		else 
		{
			//WWW.UnEscapeURL (Encoding.UTF8.GetString( www.bytes))
			Debug.Log("request result :" +www.text);
			var sstring = WWW.UnEscapeURL (www.text);
			switch (type)
			{
			case Type_GetVersionBack :
				_HandleCheckVerion (www.text);
				break;

			case Type_GetServerBack:
				_HandleServiceList (www.text, callback);
				break;
			case Type_GetCodeBack:
				_HandleCodeBack (sstring , callback);
				break;
			case Type_NoticeBack:
				_HandlerNoticeBack (www.text,callback);
				break;

			default:
				break;
			}

		}
	}


	/// <summary>
	/// Downloads the picture. 下载网络图片 未应用
	/// </summary>
	/// <returns>The picture.</returns>
	/// <param name="url">URL.</param>
	/// <param name="getData">Get data.</param>
	/// <param name="type">Type.</param>
	/// <param name="callback">Callback.</param>
	IEnumerator DownloadPicture(string url,string getData ,UnityEngine.UI.Image img=null) 
	{		
		var idfen = false;
		if (getData != "")
		{
			getData = "jsonString=" + WWW.EscapeURL (getData);//Encoding.UTF8.GetBytes();
			idfen = true;
		}
		WWW www;
		if(idfen==false)
		{
			www = new WWW (url+getData);
		}
		else
		{
			//getData
			Debug.Log (url+getData);
			www= new WWW (url+getData);
		}
		//www= new WWW ("http://59.110.29.41:8080/RichLife/account/player/getCode?jsonString=%7B%22phone%22%3A%2218618399063%22%7D");
		yield return www;

		if (www.error != null) 
		{
			Debug.Log("error is :"+ www.error);
		} 
		else 
		{
			//WWW.UnEscapeURL (Encoding.UTF8.GetString( www.bytes))
			Debug.Log("request result :" +www.text);
			var sstring = WWW.UnEscapeURL (www.text);
		}
	}

    /// <summary>
    /// 上传纹理集图片到服务器，然后显示上传的图片。此处单独作为新建角色信息时接口，后需要单独摘出
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
	IEnumerator UploadImageData(Texture2D data)
	{
		byte[] bs = data.EncodeToPNG ();
		//Encoding.UTF8.GetBytes(postData)
		WWWForm form = new WWWForm();//
		form.AddBinaryData ("picture", bs, "filename.png", "image/png");
		WWW www = new WWW(targetURL+"/user/image",form);
//		Debug.Log (Encoding.UTF8.GetString(Encoding.UTF8.GetBytes(postData)));
		yield return www;
		if (www.error != null)
		{
			Debug.Log ("error is :" + www.error);
		}
		else
		{
			Console.WriteLine ("上传图片返回的地址是"+WWW.UnEscapeURL (www.text));
			var backdata =JsonMapper.ToObject( WWW.UnEscapeURL (www.text));

			int status = int.Parse (backdata ["status"].ToString());
			string msg = backdata ["msg"].ToString ();

			if (status == 0)
			{
				var tmpPath = backdata ["data"] ["path"].ToString ();
				var playerController = UIControllerManager.Instance.GetController<Client.UI.UIPlayerInforController> ();
				playerController.SetHeadPath (tmpPath);
			}
		}
	}

    /// <summary>
    /// Http post 形式通过地址和请求参数，确定数据请求。通过type执行对应的方法，通过callBack，传入回调函数
    /// </summary>
    /// <param name="url"></param>
    /// <param name="postData"></param>
    /// <param name="type"></param>
    /// <param name="callback"></param>
    /// <returns></returns>
	IEnumerator Post(string url, string postData,string type,Action callback=null) 
	{
        //		WWWForm form = new WWWForm();
        //		foreach(KeyValuePair<string, string> postArg in postData) 
        //		{
        //			form.AddField(postArg.Key, postArg.Value);WWW.EscapeURL(
        //		}

        Console.WriteLine("请求的地址："+url+"______请求的参数："+postData);
		WWW www = new WWW(url,Encoding.UTF8.GetBytes(postData));
		Debug.Log (Encoding.UTF8.GetString(Encoding.UTF8.GetBytes(postData)));
		yield return www;
		if (www.error != null) 
		{
			Debug.Log("error is :"+ www.error);
		} 
		else
		{
			Debug.Log("request result :" + www.text);

			//JsonData tmpback = JsonMapper.ToObject (www.text);

			var sstring = WWW.UnEscapeURL (www.text);

			switch (type)
			{
			case Type_FeedBack:
				_handlerFeedback (www.text, callback);
				break;
			case Type_ModifyBack:
				_handModifyBack (www.text, callback);
				break;
			case Type_RegistBack:
				_handRegistBack (www.text, callback);
				break;
			case Type_LoginBack:
				_handLoginBack(www.text, callback);
				break;
			case Type_GetPlayerInforBack:
				_handPlayerInforBack (www.text, callback);
				break;
			case Type_blindPhone:
				_blindPhoneBackData (www.text, callback);
				break;
			case Type_CheckPhone:
				_CheckPhoneNumBackData (www.text, callback);
				break;
			default:
				break;
			}
		}
	}

	/// <summary>
	/// Checks the phone number back data.校验手机号
	/// </summary>
	/// <param name="value">Value.</param>
	/// <param name="callback">Callback.</param>
	private void _CheckPhoneNumBackData(string value, Action callback=null)
	{
		var backdata =JsonMapper.ToObject(value);
		int status = int.Parse (backdata ["status"].ToString());
		string msg = backdata ["msg"].ToString ();

		var tmpstate = 0;

		var checkController = UIControllerManager.Instance.GetController<Client.UI.UIGameBindPhoneWindowController> ();

		if (status == 0)//不能绑定
		{
			tmpstate = 0;
		}
		else if (status == 1)//已经有手机号，可以绑定
		{
			tmpstate = 1;
		}
		else if (status == 2)//该手机号没有注册，可以绑定
		{
			tmpstate = 2;
		}
		checkController.CheckPhoneState (tmpstate);
	}

	/// <summary>
	/// Blinds the phone back data.绑定手机data
	/// </summary>
	private void _blindPhoneBackData(string value , Action callback)
	{
		var backdata =JsonMapper.ToObject(value);
		int status = int.Parse (backdata ["status"].ToString());
		string msg = backdata ["msg"].ToString ();

		var bindController = UIControllerManager.Instance.GetController<Client.UI.UIGameBindPhoneWindowController> ();

		if (status == 0)
		{
			_showPlayerInforBoard ();
			bindController.setVisible (false);
			MessageHint.Show ("绑定手机号成功");

		}
		else if(status==1)
		{
			NetWorkScript.getInstance ().init ();
			var role = backdata ["data"] ["player"];

			var nickname = role ["name"].ToString ();
			var headimg = role ["avatar"].ToString ();
			var sex = int.Parse (role ["gender"].ToString ());
			var uuid = role ["id"].ToString ();
			GameModel.GetInstance.setPlayerInfor (nickname, sex, uuid, headimg);
			if (null != callback) {
				callback ();
			}
			MessageHint.Show ("绑定手机号成功");
			bindController.setVisible (false);
		}
		else
		{
			MessageHint.Show (msg);
		}
	}

    /// <summary>
    /// 处理创建玩家信息后的信息
    /// </summary>
    /// <param name="value"></param>
    /// <param name="callback"></param>
	private void _handPlayerInforBack(string value , Action callback)
	{
		//			Console.WriteLine (str);
		//request result :{"msg":"玩家角色创建成功",
		//"data":{"role":{"accountId":"25","gameNumber":"1","gender":"1","headImg":"","name":"12313213","uuid":"0007a98f-cf6f-42bf-b3a0-0f3aba2a055b"}},"status":0}
		var backdata =JsonMapper.ToObject(value);
		int status = int.Parse (backdata ["status"].ToString());
		string msg = backdata ["msg"].ToString ();

		if (status == 0)
		{
			NetWorkScript.getInstance ().init ();
			Debug.Log ("ssssssss------------"+status.ToString());
			MessageHint.Show (msg);

			var role =backdata["data"]["player"];

			var nickname = role ["name"].ToString ();
			var headimg = role["avatar"].ToString();
			var sex = int.Parse(role["gender"].ToString());
			var uuid = role["id"].ToString();

			GameModel.GetInstance.setPlayerInfor(nickname,sex,uuid,headimg);

			if (callback != null)
			{
				callback ();
			}
		}
		else if(status==1)
		{
			MessageHint.Show (msg);
		}
	}

    /// <summary>
    /// 处理登录后返回的数据
    /// </summary>
    /// <param name="value"></param>
    /// <param name="callback"></param>
	private void _handLoginBack(string value ,Action callback=null)
	{
		//LoginBackVo data = Coding<LoginBackVo>.decode (value);
		var data = JsonMapper.ToObject (value);

		var status = int.Parse (data["status"].ToString());
		var msg = data["msg"].ToString();
		//登录成功
		if (status == 0)
		{				
			var isShowBoard = false;
			if (((IDictionary)data ["data"]).Contains ("bind"))
			{
				var isBind = int.Parse (data["data"]["bind"].ToString());
				if (isBind == 0)
				{
					_showBindInforBoard ();
				}
				else if(isBind==1)				
				{
					isShowBoard = true;
//					if (isneed == 0)
//					{//如果需要弹提示框
//						_showPlayerInforBoard ();
//					}
//					else
//					{
//						NetWorkScript.getInstance ().init ();
//						var role = data ["data"] ["player"];
//
//						var nickname = role ["name"].ToString ();
//						var headimg = role ["avatar"].ToString ();
//						var sex = int.Parse (role ["gender"].ToString ());
//						var uuid = role ["id"].ToString ();
//						GameModel.GetInstance.setPlayerInfor (nickname, sex, uuid, headimg);
//						if (null != callback) {
//							callback ();
//						}
//					}
				}
			}
			else
			{
				isShowBoard = true;
			}

			if (isShowBoard == true)
			{
				if (((IDictionary)data ["data"]).Contains ("need"))
				{
					var isneed = int.Parse (data ["data"] ["need"].ToString ());
					if (isneed == 0)
					{
						//如果需要弹提示框
						_showPlayerInforBoard ();
					}
					else
					{
						NetWorkScript.getInstance ().init ();
						var role = data ["data"] ["player"];

						var nickname = role ["name"].ToString ();
						var headimg = role ["avatar"].ToString ();
						var sex = int.Parse (role ["gender"].ToString ());
						var uuid = role ["id"].ToString ();
						GameModel.GetInstance.setPlayerInfor (nickname, sex, uuid, headimg);
						if (null != callback) {
							callback ();
						}
					}
				}		
			}
		}
		else
		{
			//失败
			MessageHint.Show(msg);
		}
	}


    /// <summary>
    /// 显示创建玩家信息的面板
    /// </summary>
	private void _showPlayerInforBoard()
	{
		var inforController = UIControllerManager.Instance.GetController<Client.UI.UIPlayerInforController> ();
		inforController.windowType = 0;
		inforController.setVisible (true);
	}

    /// <summary>
    /// 显示绑定手机号的界面
    /// </summary>
	private void _showBindInforBoard()
	{
		Console.WriteLine ("出现了绑定手机号");

		var controller = UIControllerManager.Instance.GetController<Client.UI.UIGameBindPhoneWindowController> ();
		controller.setVisible (true);

	}

    /// <summary>
    /// 处理注册后返回的数据
    /// </summary>
    /// <param name="value"></param>
    /// <param name="callback"></param>
	private void _handRegistBack(string value ,Action callback=null)
	{
		var backdatavo = new PlayerRegistBackVo (); //Coding<PlayerRegistBackVo>.decode (value);

		var jsonData = JsonMapper.ToObject (value);
		backdatavo.status = int.Parse(jsonData ["status"].ToString ());
		backdatavo.msg = jsonData ["msg"].ToString ();


		if(backdatavo.status==0)//chenggong
		{
			MessageHint.Show (backdatavo.msg);
		}
		else 
		{
			MessageHint.Show (backdatavo.msg);
		}
	}

    /// <summary>
    /// 处理修改密码后返回的数据
    /// </summary>
    /// <param name="value"></param>
    /// <param name="callback"></param>
	private void _handModifyBack(string value ,Action callback=null)
	{
		var backdatavo = new PlayerRegistBackVo (); //Coding<PlayerRegistBackVo>.decode (value);
    	var jsonData = JsonMapper.ToObject (value);
		backdatavo.status = int.Parse(jsonData ["status"].ToString ());
		backdatavo.msg = jsonData ["msg"].ToString ();

		if(backdatavo.status==0)//chenggong
		{
			MessageHint.Show (backdatavo.msg);
		}
		else 
		{
			MessageHint.Show (backdatavo.msg);
		}
	}

    /// <summary>
    /// 处理提交反馈后返回的数据
    /// </summary>
    /// <param name="value"></param>
    /// <param name="callback"></param>
	private void _handlerFeedback(string value , Action callback = null)
	{
		var backVo =new FankuiBackVo() ;//Coding<FankuiBackVo>.decode (value);
		var jsonData = JsonMapper.ToObject (value);
		backVo.status = int.Parse (jsonData ["status"].ToString ());
		backVo.msg = jsonData ["msg"].ToString ();		
		
		if (backVo.status == 0)//成功
		{				
			if (null != callback)
			{
				callback ();
			}
		}
		else
		{
			//失败
		}
		MessageHint.Show (backVo.msg);
	}

    /// <summary>
    /// The request UR. 请求urlhttp://localhost:8080/RichLife
    /// </summary>            http://59.110.29.41:8080/RichLife/account/player/getCode?
    //	private string targetURL="http://59.110.29.41:8060/RichLife/account";192.168.1.18
    //private string targetURL = "http://219.232.230.61:9099";//RichLife
    private string targetURL = "http://192.168.1.18:9099";
    //private string targetURL = "http://219.232.230.61:8080";
    //private string targetURL="http://219.232.230.61:8080/RichLife";

    /// <summary>
    /// The regist path. 注册请求的地址 post  
    /// </summary>
    private readonly string RegistPath ="/user/register?";

	/// <summary>
	/// The modify password. 找回密码 post
	/// </summary>
	private readonly string ModifyPasswordPath="/user/findPassword?";

	/// <summary>
	/// The login path.登录请求的接口  post?json=?json=player/login
	/// </summary>
	private readonly string LoginPath = "/user/login?";


	/// <summary>
	/// The upload image. 上传图片
	/// </summary>
//	private readonly string UploadImg="/user/image";

	/// <summary>
	/// The get code path. 获取验证码 get
	/// </summary>
	private readonly string GetCodePath="/user/getCode?";
	/// <summary>
	/// The check version path. 检查游戏客户端版本
	/// </summary>
	private readonly string CheckVersionPath="/game/checkVersion?";//json=
	/// <summary>
	/// The feed back path. 游戏客户端反馈/game/feedback?json=
	/// </summary>
	private readonly string FeedBackPath="/feedback?";

	/// <summary>
	/// The server list path.获取服务器列表
	/// </summary>
	private readonly string ServerListPath="/game/server/list";
	//http://59.110.29.41:8060/RichLife/account/game/server/list  http://59.110.29.41:8060/RichLife/account/game/server/list

	//创建角色，绑定手机
	private readonly string PlayerInforPath="/user/player/perfectInfo?";
	/// <summary>
	/// The blind phone path.绑定手机号
	/// </summary>
	private readonly string BlindPhonePath = "/user/bindPhone";
	/// <summary>
	/// The check phone number path. 验证手机号
	/// </summary>
	private readonly string CheckPhoneNumPath = "/user/authPhone";
	/// <summary>
	/// The download pic path.下载网络图片
	/// </summary>
	private readonly string DownloadPicPath="/user/ShowImage";

	/// <summary>
	/// The game notice path.获取游戏公告
	/// </summary>
	private readonly string GameNoticePath = "/gameNotice/find";
//	private HttpWebRequest request;
	private static HttpRequestManager _instance;
	public List<string> serviceList=new List<string>();

	public string identyCode="";

	public static HttpRequestManager GetInstance()
	{
		return _instance;
	}

	public HttpRequestManager ()
	{
		
	}
    /// <summary>
    /// 处理检查游戏版本后返回的数据
    /// </summary>
    /// <param name="value"></param>
	private void _HandleCheckVerion(string value)
	{
		var jsonData = JsonMapper.ToObject (value);
		var versionNum = float.Parse (jsonData ["data"] ["versionCode"].ToString ());
		if (versionNum > GameModel.CurVersion)
		{
			showTipNewVersion ();
			GameModel.GetInstance.isNeedNewVersion = true;
		}
	}

	int times=0;
    /// <summary>
    /// 显示版本更新的请求
    /// </summary>
	private void showTipNewVersion()
	{
		StartCoroutine(showGameTip());
	}

	IEnumerator showGameTip()
	{
		yield return new WaitForSeconds (0.5f);
		times++;
		var gameTip = UIControllerManager.Instance.GetController<Client.UI.UIGameSimpleTipController> ();
		gameTip.SetSureTip ("当前版本过低，请更新最新版本"+times.ToString(),showTipNewVersion);
		gameTip.setVisible (true);
	}

    /// <summary>
    /// 处理请求服务器列表后返回的信息
    /// </summary>
    /// <param name="value"></param>
    /// <param name="callback"></param>
	private void _HandleServiceList(string value , Action callback)
	{
		serviceList.Clear ();
		//request result :{"msg":"查询成功","data":[{"serverName":"电信"},{"serverName":"联通"}],"status":0}
		JsonData data = JsonMapper.ToObject (value);
		var state = int.Parse (data ["status"].ToString ());
		if (state == 0)
		{
			var jsonlist = data["data"];
			if (jsonlist.IsArray == true)
			{
				for (int i = 0; i < jsonlist.Count; i++)
				{
					var serverdata = jsonlist [i];
					this.serviceList.Add (serverdata["serverName"].ToString());
				}
			}
		}
		else
		{
			MessageHint.Show ("获取服务器失败");
		}
		if (null != callback)
		{
			callback ();
		}
	}

	/// <summary>
	/// Handlers the notice back. 获取到公告的返回信息
	/// </summary>
	/// <param name="value">Value.</param>
	/// <param name="callback">Callback.</param>
	private void _HandlerNoticeBack (string value, Action callback)
	{
		var backData = JsonMapper.ToObject (value);
		var status = int.Parse (backData["status"].ToString());

		if (status == 0)
		{
			if (((IDictionary)backData).Contains ("data"))
			{
				var noticeList = backData ["data"];
				if (noticeList.IsArray)
				{
					if (noticeList.Count > 0)
					{
						for (var i = 0; i < noticeList.Count; i++)
						{
							var tip = noticeList[i];

							var title = tip["title"].ToString();
							var content = tip ["content"].ToString ();
							var type =int.Parse(tip ["type"].ToString ());

							var gonggaovo = new GonggaoVo ();
							gonggaovo.title = title;
							gonggaovo.content = content;
							gonggaovo.type = type;
							Debug.Log ("~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + gonggaovo.title);
							GameModel.GetInstance.gonggaoList.Add (gonggaovo);
						}

						if (GameModel.GetInstance.isFirstInGameHall == true)
						{
							_ShowGonggao ();
						}
					}
				}
			}			
		}
	}

	/// <summary>
	/// Shows the gonggao.游戏公告
	/// </summary>
	private void _ShowGonggao()
	{
		if (GameModel.GetInstance.gonggaoList.Count > 0)
		{
			var gonggaocontroller = UIControllerManager.Instance.GetController<Client.UI.UIGongGaoController> ();
			gonggaocontroller.inforList = GameModel.GetInstance.gonggaoList;
			gonggaocontroller.setVisible (true);
		}
	}

    /// <summary>
    /// 处理获取验证码后返回的消息
    /// </summary>
    /// <param name="value"></param>
    /// <param name="callback"></param>
	private void _HandleCodeBack(string value , Action callback)
	{
		//{"msg":"获取验证码成功","data":{"code":"7491"},"status":0}
		Debug.Log ("sssssss"+value.ToString());
		var getcodeback = new PlayerGetCodeBackVo (); //Coding<PlayerGetCodeBackVo>.decode (value);
		JsonData data = JsonMapper.ToObject (value);
		getcodeback.status = int.Parse (data ["status"].ToString ());
		getcodeback.msg = data ["msg"].ToString ();
		getcodeback.code = data ["data"] ["code"].ToString ();
		if(getcodeback.status==0)//成功
		{
			identyCode = getcodeback.code;
			MessageHint.Show ("已经发验证码，注意接收");
		}
		else
		{
			Console.WriteLine (getcodeback.msg);
		}
	}

    /// <summary>
    /// 把2d纹理集合转成图片，上传到服务器
    /// </summary>
    /// <param name="data"></param>
	public void UpLoadImage(Texture2D data)
	{
		StartCoroutine (UploadImageData (data));
	}
    /// <summary>
    /// 新建玩家角色信息
    /// </summary>
    /// <param name="data"></param>
    /// <param name="callback"></param>
	public void GetPlayerInfor(string data,Action callback=null)
	{
		var value = "jsonString=" + data;
		StartCoroutine(Post (targetURL+PlayerInforPath,value,Type_GetPlayerInforBack,callback));
	}

	/// <summary>
	/// Gets the regist data. 发送注册请求，获得反馈 post
	/// </summary>
	/// <returns>The regist data.</returns>
	/// <param name="data">Data.</param>
	public  void GetRegistData(string data , Action callback=null)
	{
		var value = "jsonString=" + data;
		StartCoroutine(Post (targetURL+RegistPath,value,Type_RegistBack,callback));
	}

	/// <summary>
	/// Gets the login data. 发送登录请求，获得反馈数据 post
	/// </summary>
	/// <returns>The login data.</returns>
	/// <param name="data">Data.</param>
	public void GetLoginData(string data,Action callback=null)
	{
		var value = "jsonString=" + data;			
		StartCoroutine(Post(targetURL+LoginPath,value,Type_LoginBack,callback));
	}

	/// <summary>
	/// Gets the modify data. 或得修改密码的数据
	/// </summary>
	/// <returns>The modify data.</returns>
	/// <param name="data">Data.</param>
	public void GetModifyData(string data,Action callback=null)
	{
		var value = "jsonString=" + data;
		StartCoroutine(Post (targetURL+ModifyPasswordPath,value,Type_ModifyBack,callback));
	}
    /// <summary>
    /// 绑定手机号
    /// </summary>
    /// <param name="data"></param>
    /// <param name="callback"></param>
	public void BindPhone(string data, Action callback=null)
	{
		var value = "jsonString=" + data;
		StartCoroutine(Post (targetURL+BlindPhonePath,value,Type_blindPhone,callback));
	}

	/// <summary>
	/// Checks the phone number. 校验手机号
	/// </summary>
	/// <param name="data">Data.</param>
	/// <param name="callback">Callback.</param>
	public void CheckPhoneNum(string data , Action callback=null)
	{
		var value = "jsonString=" + data;
		Console.WriteLine (CheckPhoneNumPath+value);
		StartCoroutine(Post (targetURL+CheckPhoneNumPath,value,Type_CheckPhone,callback));
	}

	/// <summary>
	/// Gets the check code data.获取验证码的数据
	/// </summary>
	/// <returns>The check code data.</returns>
	/// <param name="data">Data.</param>
	public void GetCheckCodeData(string data,Action callback=null)
	{
		var value = "jsonString=" + data;
		Console.WriteLine ("sssssss--------------"+value);
		StartCoroutine( Get (targetURL+GetCodePath,data,Type_GetCodeBack,callback));
		//return HttpGet (targetURL+GetCodePath,data);
	}

	/// <summary>
	/// Gets the check version data. 获取检测版本号的数据
	/// </summary>
	/// <returns>The check version data.</returns>
	public void GetCheckVersionData()
	{
		StartCoroutine (Get(targetURL+CheckVersionPath,"",Type_GetVersionBack));
	}

	/// <summary>
	/// Gets the game notice.获取游戏公告
	/// </summary>
	public void GetGameNotice()
	{
		StartCoroutine (Get(targetURL+GameNoticePath,"",Type_NoticeBack));
	}

	/// <summary>
	/// Gets the feed back data.发送反馈信息，并且返回
	/// </summary>
	/// <returns>The feed back data.</returns>
	/// <param name="data">Data.</param>
	public void GetFeedBackData(string data, Action callback=null)
	{			
		var value = "jsonString=" + data;
		StartCoroutine(Post(targetURL+FeedBackPath,value,Type_FeedBack,callback));
	}

	/// <summary>
	/// Gets the check server data.
	/// </summary>
	/// <returns>The check server data.</returns>
	/// <param name="data">Data.</param>
	public void GetServerListData(string data="",Action callback=null)
	{		
		//return HttpGet (targetURL+ServerListPath,"");
		StartCoroutine( Get (targetURL + ServerListPath, data, Type_GetServerBack, callback));
	}
}