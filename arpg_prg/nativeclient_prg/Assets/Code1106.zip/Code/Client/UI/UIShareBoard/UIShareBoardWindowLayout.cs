﻿using System;

namespace Client.UI
{
	public partial class UIShareBoardWindow
	{
		class Layout
		{
			public static string btn_sharewechatmoment="btnsharewechatment";
			public static string btn_sharewechat="btnsharewechat";

			public static string btn_imgbg="bgimg";
		}
	}
}

