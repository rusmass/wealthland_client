﻿using System;

namespace Client.UI
{
	public partial class UIGameSimpleTipWindow
	{
		class Layout
		{
			public static string lb_txt="tipTxt";
			public static string btn_cancle="tipbtn";
			public static string btn_sure="knowbtn";

			public static string img_bgimg="bgimg";
		}
	}
}

