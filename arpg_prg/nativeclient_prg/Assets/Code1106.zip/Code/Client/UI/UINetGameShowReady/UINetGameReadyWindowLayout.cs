﻿using System;

namespace Client.UI
{
	public partial class UINetGameReadyWindow
	{
		class Layout
		{
			public static string head="head";
			public static string lb_name="nametxt";
			public static string lb_ready="readytxt";

			public static string img_ready="img_ready";
		}
	}
}

