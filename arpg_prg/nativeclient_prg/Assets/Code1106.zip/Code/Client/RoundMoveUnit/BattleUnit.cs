﻿using System;

namespace Client.Unit
{
	public abstract class BattleUnit
	{
		public abstract void Tick(float deltaTime);
	}
}
