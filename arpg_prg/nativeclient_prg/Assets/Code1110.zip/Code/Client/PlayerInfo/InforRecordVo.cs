﻿using System;

namespace Client
{
    /// <summary>
    /// 多处引用，记录索引值，标题和数量
    /// </summary>
	public class InforRecordVo
    {
        public int index;

        public string title;

        public float num;
    }
}

