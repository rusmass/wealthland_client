﻿using System;

namespace Client.UI
{
	public partial class UIModifyWindow
	{
		class Layout
		{
			public static string inputPhone="inputphone";
			public static string inputIdentify="inputidentify";
			public static string inputScret="inputscret";
			public static string inputScretAgain="inputscretagain";

			public static string btn_getIndentify="btngetidentify";

			public static string btn_sure="btnsure";
			public static string btn_sureModify="btnsuremodify";

			public static string btn_close="btn_close";

			public static string img_word="img_word";

			/// <summary>
			/// The lb count. 获取验证码后显示倒计时的框
			/// </summary>
			public static string lb_count="lb_count";
		}
	}
}

